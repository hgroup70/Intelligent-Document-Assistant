"""Small display helpers."""

from __future__ import annotations

import html
import re
from datetime import datetime


def human_size(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


def human_time(iso: str) -> str:
    try:
        return datetime.fromisoformat(iso).strftime("%b %d, %Y | %H:%M UTC")
    except ValueError:
        return iso


def highlight(text: str, term: str) -> str:
    """HTML-escape ``text`` and wrap case-insensitive matches of ``term`` in <mark>."""
    escaped = html.escape(text)
    if not term:
        return escaped
    pattern = re.compile(re.escape(html.escape(term)), re.IGNORECASE)
    return pattern.sub(lambda m: f"<mark>{m.group(0)}</mark>", escaped)


def truncate(text: str, limit: int) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "..."
