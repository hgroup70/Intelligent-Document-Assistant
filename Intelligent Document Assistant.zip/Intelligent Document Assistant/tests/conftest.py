import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def make_pdf(pages: list[str]) -> bytes:
    """Build a small text PDF with reportlab (one string per page)."""
    import io

    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    for text in pages:
        y = 800
        for line in text.split("\n"):
            c.drawString(60, y, line)
            y -= 16
        c.showPage()
    c.save()
    return buf.getvalue()


@pytest.fixture
def sample_pdf() -> bytes:
    return make_pdf([
        "Quarterly Report\nRevenue grew by 12 percent in the third quarter.",
        "Risks\nSupply chain delays remain the main risk for next year.",
        "Conclusion\nThe board recommends expanding into two new markets.",
    ])
