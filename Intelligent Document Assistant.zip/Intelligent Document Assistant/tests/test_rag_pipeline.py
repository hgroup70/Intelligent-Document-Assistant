"""End-to-end pipeline test with a fake LLM and fake embeddings (no API key needed).

Skipped automatically if LangChain / FAISS are not installed.
"""

from pathlib import Path

import pytest

pytest.importorskip("langchain_core")
pytest.importorskip("langchain_community")
pytest.importorskip("faiss")

from langchain_core.embeddings import DeterministicFakeEmbedding  # noqa: E402

from src.core import service as service_mod  # noqa: E402
from src.core.config import get_settings  # noqa: E402
from src.core.document_processor import PageText  # noqa: E402
from src.core.storage import ChatMessage, Workspace  # noqa: E402
from src.core.summarizer import Summarizer  # noqa: E402
from tests.conftest import make_pdf  # noqa: E402


class _Resp:
    def __init__(self, content):
        self.content = content


class FakeLLM:
    """Responds based on which system prompt it receives."""

    def invoke(self, messages):
        system = messages[0].content
        if "standalone question" in system:
            return _Resp("What are the main risks?")
        if "propose" in system:
            return _Resp("1. What grew?\n- Why expand?")
        if "condensing one section" in system:
            return _Resp("- section notes")
        return _Resp("## Overview\nA report.\n\n## Key Insights\n- Revenue grew\n\n## Conclusions\nExpand.")

    def stream(self, messages):
        assert "[1]" in messages[0].content  # numbered context is present
        yield _Resp("Supply chain delays ")
        yield _Resp("are the main risk [1].")


@pytest.fixture
def service(tmp_path, monkeypatch):
    monkeypatch.setattr(service_mod, "get_chat_model", lambda cfg, streaming=False: FakeLLM())
    monkeypatch.setattr(service_mod, "get_embeddings", lambda cfg: DeterministicFakeEmbedding(size=32))
    settings = get_settings().with_overrides(data_dir=Path(tmp_path), openai_api_key="sk-test")
    return service_mod.DocumentService(settings, Workspace(settings.data_dir, "anon_test")), settings


def test_full_pipeline(service, sample_pdf):
    svc, settings = service
    cfg = settings.provider_config("openai")

    record, duplicate, index_error = svc.ingest("report.pdf", sample_pdf, cfg)
    assert not duplicate and index_error is None
    assert svc.is_indexed(record.id, cfg)
    assert svc.ingest("copy.pdf", sample_pdf, cfg)[1] is True  # duplicate detected

    summary = svc.summarize(record, "medium", cfg)
    assert summary["content"].startswith("## Overview")
    assert svc.workspace.get_summaries(record.id)["medium"]

    assert svc.suggest_questions(record, cfg) == ["What grew?", "Why expand?"]

    engine = svc.build_qa_engine([record], cfg, k=3)
    history = [ChatMessage("user", "What grew?"), ChatMessage("assistant", "Revenue [1].")]
    answer, citations = engine.answer("and the risks?", history)
    assert "[1]" in answer
    assert citations[0].cited and citations[0].page in {1, 2, 3}

    svc.delete(record.id)
    assert svc.workspace.list_documents() == []


def test_map_reduce_for_long_documents():
    pages = [PageText(i, "lorem ipsum dolor " * 500) for i in range(1, 15)]
    result = Summarizer(FakeLLM(), "openai", "fake").summarize(pages, "detailed")
    assert result["strategy"] == "map-reduce"
