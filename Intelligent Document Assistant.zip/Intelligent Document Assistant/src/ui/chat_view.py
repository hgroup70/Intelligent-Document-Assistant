"""Q&A chat tab with streaming answers, citations and per-document memory."""

from __future__ import annotations

import html

import streamlit as st

from src.core.errors import AppError
from src.core.export import conversation_to_markdown, safe_filename
from src.core.prompts import GENERIC_EXAMPLE_QUESTIONS
from src.core.qa_engine import mark_cited
from src.core.service import DocumentService
from src.core.storage import ChatMessage, DocumentRecord
from src.ui import state
from src.ui.formatting import truncate


def render_chat(svc: DocumentService, doc: DocumentRecord) -> None:
    docs = svc.workspace.list_documents()
    cfg = state.provider_config()

    c1, c2, c3 = st.columns([3, 1.2, 1.2], vertical_alignment="center")
    with c1:
        # Not keyed: keyed widget state is discarded when the widget is hidden
        # (e.g. on another tab), and we want this choice to persist.
        st.session_state.search_all_docs = st.toggle(
            f"Search across all {len(docs)} documents" if len(docs) > 1 else "Search across all documents",
            value=bool(st.session_state.search_all_docs) and len(docs) > 1,
            disabled=len(docs) < 2,
            help="Off: answers come only from the selected document. "
                 "On: every document in your library is searched.",
        )
    scope = state.chat_scope(doc)
    conv = state.active_conversation(svc, scope)
    records = docs if scope == "all" else [doc]

    if c2.button("New chat", width="stretch", disabled=not conv.messages,
                 help="Start a fresh conversation. The current one stays in Saved sessions."):
        state.set_conversation(svc.workspace.new_conversation(scope))
        st.rerun()
    if conv.messages:
        c3.download_button(
            "Export", conversation_to_markdown(conv, [r.name for r in records]),
            file_name=safe_filename(conv.title, ".md"), mime="text/markdown", width="stretch",
        )

    if cfg is None:
        st.info("Add an OpenAI or Gemini API key in **Settings** (sidebar) to start asking questions.")

    # history
    for msg in conv.messages:
        with st.chat_message(msg.role):
            st.markdown(msg.content)
            if msg.role == "assistant" and msg.citations:
                _render_citations(msg.citations)

    if not conv.messages:
        _render_examples(svc, doc, scope, cfg is not None)

    # input
    placeholder = "Ask anything about your documents..." if scope == "all" else f"Ask about {truncate(doc.name, 40)}..."
    typed = st.chat_input(placeholder, disabled=cfg is None)
    question = typed or st.session_state.pop("pending_question", None)
    if not question or cfg is None:
        return

    question = question.strip()[:4000]
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        try:
            needs_index = [r for r in records if not svc.is_indexed(r.id, cfg)]
            label = (f"Indexing {len(needs_index)} document(s) for {cfg.provider} - first time only..."
                     if needs_index else "Searching the document...")
            with st.spinner(label):
                engine = svc.build_qa_engine(records, cfg, k=st.session_state.retrieval_k)
                retrieval = engine.retrieve(question, conv.messages)
            answer = st.write_stream(engine.stream_answer(retrieval, conv.messages))
            answer = answer if isinstance(answer, str) else "".join(map(str, answer))
        except AppError as exc:
            st.error(exc.user_message)
            if exc.detail:
                with st.expander("Technical details"):
                    st.code(exc.detail)
            return
        if not answer.strip():
            answer = "_The model returned an empty answer. Please try rephrasing your question._"
            st.markdown(answer)

        citations = mark_cited(answer, retrieval.citations)
        cite_dicts = [c.to_dict() for c in citations]
        _render_citations(cite_dicts)
        if retrieval.standalone_question != question:
            st.caption(f"Searched for: *{retrieval.standalone_question}*")

    conv.messages.append(ChatMessage(role="user", content=question))
    conv.messages.append(ChatMessage(role="assistant", content=answer, citations=cite_dicts,
                                     model=f"{cfg.provider}/{cfg.chat_model}"))
    if conv.title == "New conversation":
        conv.title = truncate(question, 70)
    svc.workspace.save_conversation(conv)
    st.rerun()  # re-render so the buttons above reflect the new state


def _render_citations(citations: list[dict]) -> None:
    cited = [c for c in citations if c.get("cited")]
    other = [c for c in citations if not c.get("cited")]
    label = f"Sources ({len(cited)} cited)" if cited else f"Retrieved passages ({len(other)})"
    with st.expander(label):
        for c in cited or other:
            _citation_block(c, dim=False)
        if cited and other:
            st.caption("Also retrieved, but not cited:")
            for c in other:
                _citation_block(c, dim=True)


def _citation_block(c: dict, *, dim: bool) -> None:
    where = f"page {c['page']}" if c.get("page") else f"section {int(c.get('chunk_id') or 0) + 1}"
    excerpt = html.escape(truncate(c.get("excerpt", ""), 600))
    st.markdown(
        f'<div class="citation{" citation-dim" if dim else ""}">'
        f'<div class="citation-head">[{c["index"]}] {html.escape(c.get("doc_name", ""))} | {where}</div>'
        f"{excerpt}</div>",
        unsafe_allow_html=True,
    )


def _render_examples(svc: DocumentService, doc: DocumentRecord, scope: str, enabled: bool) -> None:
    suggested = svc.workspace.get_suggested_questions(doc.id) if scope != "all" else []
    with st.container(border=True):
        st.markdown("##### Try asking")
        st.caption("Answers are based **only** on your document and include the passages they come from. "
                   "Follow-up questions remember the conversation.")
        questions = suggested or GENERIC_EXAMPLE_QUESTIONS
        cols = st.columns(2)
        for i, q in enumerate(questions[:6]):
            if cols[i % 2].button(q, key=f"example_{scope}_{i}", width="stretch", disabled=not enabled):
                st.session_state.pending_question = q
                st.rerun()
        if scope != "all" and not suggested and enabled:
            if st.button("Suggest questions specific to this document", type="tertiary"):
                cfg = state.provider_config()
                with st.spinner("Reading the document..."):
                    try:
                        svc.suggest_questions(doc, cfg)  # type: ignore[arg-type]
                    except AppError as exc:
                        st.error(exc.user_message)
                        return
                st.rerun()
