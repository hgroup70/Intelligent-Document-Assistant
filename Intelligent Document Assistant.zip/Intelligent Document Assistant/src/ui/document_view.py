"""Document text tab: browse and search the extracted text."""

from __future__ import annotations

import re

import streamlit as st

from src.core.service import DocumentService
from src.core.storage import DocumentRecord
from src.ui.formatting import highlight

_MAX_RESULTS = 50


def render_document(svc: DocumentService, doc: DocumentRecord) -> None:
    pages = svc.workspace.load_pages(doc.id)
    st.caption("This is the text the assistant works from. If something is missing here "
               "(e.g. text inside images), the assistant can't see it either.")

    term = st.text_input("Find in document", placeholder="Search for a word or phrase...",
                         key=f"find_{doc.id}").strip()

    if term:
        pattern = re.compile(re.escape(term), re.IGNORECASE)
        hits = [(p, len(pattern.findall(p.text))) for p in pages if pattern.search(p.text)]
        total = sum(n for _, n in hits)
        if not hits:
            st.info(f"No matches for '{term}'.")
            return
        where = f" on {len(hits)} page(s)" if doc.file_type == "pdf" else ""
        st.success(f"{total} match(es){where}.")
        for page, count in hits[:_MAX_RESULTS]:
            label = f"Page {page.number}" if page.number else "Text"
            with st.expander(f"{label} - {count} match(es)", expanded=len(hits) <= 3):
                st.markdown(_snippets(page.text, pattern, term), unsafe_allow_html=True)
        if len(hits) > _MAX_RESULTS:
            st.caption(f"Showing the first {_MAX_RESULTS} pages with matches.")
        return

    if doc.file_type == "pdf" and len(pages) > 1:
        number = st.number_input("Page", min_value=1, max_value=len(pages), value=1, step=1,
                                 key=f"page_{doc.id}")
        page = pages[int(number) - 1]
        text = page.text or "_No text found on this page (it may be an image)._"
    else:
        text = pages[0].text if pages else ""
    with st.container(height=520, border=True):
        st.text(text)


def _snippets(text: str, pattern: re.Pattern, term: str, radius: int = 180, limit: int = 8) -> str:
    parts = []
    for match in list(pattern.finditer(text))[:limit]:
        start, end = max(0, match.start() - radius), min(len(text), match.end() + radius)
        chunk = text[start:end].replace("\n", " ")
        prefix = "..." if start > 0 else ""
        suffix = "..." if end < len(text) else ""
        parts.append(f"<p>{prefix}{highlight(chunk, term)}{suffix}</p>")
    return "".join(parts)
