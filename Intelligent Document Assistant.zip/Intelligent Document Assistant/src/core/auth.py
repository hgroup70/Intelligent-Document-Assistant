"""Login helpers and workspace ids.

If AUTH_ENABLED is off, every browser session gets a random workspace.
If it's on, users sign in with APP_USERS from .env and each user keeps
their own workspace.

Passwords can be plain text or "sha256:<hex>":
    python -c "import hashlib; print('sha256:' + hashlib.sha256(b'pw').hexdigest())"
"""

from __future__ import annotations

import hashlib
import hmac
import secrets

from .errors import AuthenticationError


def hash_password(password: str) -> str:
    return "sha256:" + hashlib.sha256(password.encode("utf-8")).hexdigest()


def verify_password(provided: str, stored: str) -> bool:
    if stored.startswith("sha256:"):
        candidate = hash_password(provided)
        return hmac.compare_digest(candidate, stored)
    return hmac.compare_digest(provided.encode("utf-8"), stored.encode("utf-8"))


def authenticate(username: str, password: str, users: dict[str, str]) -> str:
    """Return the workspace id for valid credentials, else raise."""
    username = (username or "").strip()
    stored = users.get(username)
    # Always run a comparison to keep timing roughly constant.
    ok = verify_password(password or "", stored or "sha256:" + "0" * 64)
    if not stored or not ok:
        raise AuthenticationError("Invalid username or password.")
    return f"user_{username}"


def new_anonymous_workspace_id() -> str:
    return f"anon_{secrets.token_hex(8)}"
