"""Text extraction for PDF and plain text files.

pdfplumber is used first, pypdf as a fallback for files it can't open.
Text is kept per page so answers can point to page numbers.
"""

from __future__ import annotations

import hashlib
import io
import logging
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

from .errors import DocumentProcessingError, FileTooLargeError, UnsupportedFileError

logger = logging.getLogger(__name__)

PDF_EXTENSIONS = {".pdf"}
TEXT_EXTENSIONS = {".txt", ".md", ".markdown", ".text"}
SUPPORTED_EXTENSIONS = PDF_EXTENSIONS | TEXT_EXTENSIONS

# A PDF that yields fewer characters than this per page on average is almost
# certainly a scanned image without a text layer.
_MIN_CHARS_PER_PAGE = 20


@dataclass
class PageText:
    number: int | None  # 1-based page number; None for plain-text files
    text: str


@dataclass
class ExtractedDocument:
    name: str
    file_type: str  # "pdf" | "text"
    size_bytes: int
    sha256: str
    pages: list[PageText]
    warnings: list[str] = field(default_factory=list)

    @property
    def full_text(self) -> str:
        return "\n\n".join(p.text for p in self.pages if p.text)

    @property
    def char_count(self) -> int:
        return sum(len(p.text) for p in self.pages)

    @property
    def word_count(self) -> int:
        return sum(len(p.text.split()) for p in self.pages)

    @property
    def page_count(self) -> int | None:
        return len(self.pages) if self.file_type == "pdf" else None
# Cleaning
_HYPHEN_BREAK = re.compile(r"(\w)-\n(\w)")
_MULTI_SPACE = re.compile(r"[ \t\u00a0]+")
_MULTI_NEWLINE = re.compile(r"\n{3,}")


def clean_text(text: str) -> str:
    """Normalize extracted text without destroying paragraph structure."""
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\x00", "").replace("\ufeff", "").replace("\r\n", "\n").replace("\r", "\n")
    text = _HYPHEN_BREAK.sub(r"\1\2", text)  # re-join words split across lines
    text = _MULTI_SPACE.sub(" ", text)
    text = "\n".join(line.strip() for line in text.split("\n"))
    text = _MULTI_NEWLINE.sub("\n\n", text)
    return text.strip()
# Public API
def validate_upload(name: str, size_bytes: int, max_size_mb: int) -> str:
    """Validate extension and size. Returns the normalized extension."""
    ext = Path(name).suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        supported = ", ".join(sorted(SUPPORTED_EXTENSIONS))
        raise UnsupportedFileError(
            f"'{name}' is not a supported file type. Supported formats: {supported}."
        )
    if size_bytes == 0:
        raise DocumentProcessingError(f"'{name}' is empty.")
    limit = max_size_mb * 1024 * 1024
    if size_bytes > limit:
        raise FileTooLargeError(
            f"'{name}' is {size_bytes / 1024 / 1024:.1f} MB, which exceeds the "
            f"{max_size_mb} MB limit."
        )
    return ext


def extract_document(
    name: str,
    data: bytes,
    *,
    max_size_mb: int = 50,
    max_pages: int = 500,
) -> ExtractedDocument:
    """Extract text from an uploaded file.

    Raises:
        UnsupportedFileError, FileTooLargeError, DocumentProcessingError
    """
    ext = validate_upload(name, len(data), max_size_mb)
    digest = hashlib.sha256(data).hexdigest()

    if ext in PDF_EXTENSIONS:
        pages, warnings = _extract_pdf(name, data, max_pages)
        file_type = "pdf"
    else:
        pages, warnings = _extract_text(name, data), []
        file_type = "text"

    doc = ExtractedDocument(
        name=name,
        file_type=file_type,
        size_bytes=len(data),
        sha256=digest,
        pages=pages,
        warnings=warnings,
    )

    if doc.char_count == 0:
        if file_type == "pdf":
            raise DocumentProcessingError(
                f"No text could be extracted from '{name}'. It is probably a scanned "
                "PDF (images only). Run it through OCR first (e.g. `ocrmypdf`) and "
                "upload the result."
            )
        raise DocumentProcessingError(f"'{name}' contains no readable text.")

    if file_type == "pdf" and doc.char_count / max(len(pages), 1) < _MIN_CHARS_PER_PAGE:
        doc.warnings.append(
            "Very little text was found - parts of this PDF may be scanned images. "
            "Answers will only cover the text that could be extracted."
        )
    return doc
# PDF
def _extract_pdf(name: str, data: bytes, max_pages: int) -> tuple[list[PageText], list[str]]:
    warnings: list[str] = []
    try:
        pages = _extract_pdf_pdfplumber(data, max_pages)
    except FileTooLargeError:
        raise
    except Exception as exc:  # fall back to pypdf below
        if _looks_encrypted(exc):
            raise DocumentProcessingError(
                f"'{name}' is password-protected. Please upload an unlocked copy."
            ) from exc
        logger.warning("pdfplumber failed on %s (%s); falling back to pypdf", name, exc)
        try:
            pages = _extract_pdf_pypdf(data, max_pages)
            warnings.append("Used fallback PDF parser; layout may be less accurate.")
        except FileTooLargeError:
            raise
        except Exception as exc2:
            if _looks_encrypted(exc2):
                raise DocumentProcessingError(
                    f"'{name}' is password-protected. Please upload an unlocked copy."
                ) from exc2
            raise DocumentProcessingError(
                f"'{name}' could not be read. The file may be corrupted or not a real PDF.",
                detail=f"pdfplumber: {exc!r}; pypdf: {exc2!r}",
            ) from exc2

    empty = [p.number for p in pages if not p.text]
    if empty and len(empty) != len(pages):
        shown = ", ".join(str(n) for n in empty[:10]) + ("..." if len(empty) > 10 else "")
        warnings.append(f"No text found on {len(empty)} page(s): {shown}.")
    return pages, warnings


def _check_page_limit(count: int, max_pages: int) -> None:
    if count > max_pages:
        raise FileTooLargeError(
            f"This PDF has {count} pages, which exceeds the {max_pages}-page limit."
        )


def _extract_pdf_pdfplumber(data: bytes, max_pages: int) -> list[PageText]:
    import pdfplumber

    pages: list[PageText] = []
    with pdfplumber.open(io.BytesIO(data)) as pdf:
        _check_page_limit(len(pdf.pages), max_pages)
        for i, page in enumerate(pdf.pages, start=1):
            try:
                raw = page.extract_text(x_tolerance=2, y_tolerance=3) or ""
            except Exception as exc:  # a single bad page shouldn't kill the doc
                logger.warning("Failed to extract page %s: %s", i, exc)
                raw = ""
            pages.append(PageText(number=i, text=clean_text(raw)))
            page.flush_cache()  # keep memory flat on large documents
    return pages


def _extract_pdf_pypdf(data: bytes, max_pages: int) -> list[PageText]:
    from pypdf import PdfReader

    reader = PdfReader(io.BytesIO(data))
    if reader.is_encrypted:
        try:
            if not reader.decrypt(""):
                raise PermissionError("encrypted")
        except Exception as exc:
            raise PermissionError("encrypted PDF") from exc
    _check_page_limit(len(reader.pages), max_pages)
    return [
        PageText(number=i, text=clean_text(page.extract_text() or ""))
        for i, page in enumerate(reader.pages, start=1)
    ]


def _looks_encrypted(exc: Exception) -> bool:
    text = f"{type(exc).__name__} {exc}".lower()
    return any(word in text for word in ("password", "encrypt", "permissionerror"))
# Plain text
def _decode(data: bytes) -> str:
    encodings = ["utf-8-sig", "cp1252", "latin-1"]
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        encodings.insert(0, "utf-16")
    for encoding in encodings:
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _extract_text(name: str, data: bytes) -> list[PageText]:
    if b"\x00" in data[:4096] and data[:2] not in (b"\xff\xfe", b"\xfe\xff"):
        raise DocumentProcessingError(f"'{name}' looks like a binary file, not plain text.")
    return [PageText(number=None, text=clean_text(_decode(data)))]
