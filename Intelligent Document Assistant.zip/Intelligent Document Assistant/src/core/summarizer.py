"""Summaries.

Small documents go to the model in one call. Bigger ones are split into
sections, each section is turned into notes, and the notes are combined
into the final summary (map-reduce).
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING

from .document_processor import PageText
from .llm_provider import content_to_text, to_llm_error
from .prompts import (
    MAP_SYSTEM_PROMPT,
    REDUCE_PREFIX,
    SUGGEST_QUESTIONS_PROMPT,
    SUMMARY_STYLES,
    summary_system_prompt,
)
from .storage import utc_now

if TYPE_CHECKING:  # pragma: no cover
    from langchain_core.language_models import BaseChatModel

logger = logging.getLogger(__name__)

ProgressFn = Callable[[float, str], None]

# ~4 characters per token. 60k chars ~ 15k tokens: fits comfortably in every
# modern model's context while leaving room for the answer.
STUFF_CHAR_LIMIT = 60_000
SECTION_CHARS = 12_000
MAX_SECTIONS = 40
MAX_PARALLEL = 4


def build_sections(pages: list[PageText], section_chars: int = SECTION_CHARS) -> list[str]:
    """Group page texts into sections of roughly ``section_chars`` characters,
    with page markers so notes can keep page references."""
    total = sum(len(p.text) for p in pages)
    # Grow sections for huge documents so we never exceed MAX_SECTIONS calls.
    section_chars = max(section_chars, -(-total // MAX_SECTIONS))

    sections: list[str] = []
    current: list[str] = []
    size = 0
    for page in pages:
        if not page.text:
            continue
        label = f"[Page {page.number}]\n" if page.number else ""
        text = page.text
        # Very long single "pages" (e.g. plain-text files) are split by paragraphs.
        pieces = [text] if len(text) <= section_chars else _split_long(text, section_chars)
        for i, piece in enumerate(pieces):
            block = (label if i == 0 else "") + piece
            if size + len(block) > section_chars and current:
                sections.append("\n\n".join(current))
                current, size = [], 0
            current.append(block)
            size += len(block)
    if current:
        sections.append("\n\n".join(current))
    return sections


def _split_long(text: str, limit: int) -> list[str]:
    parts, buf = [], ""
    for para in text.split("\n\n"):
        while len(para) > limit:  # pathological: no paragraph breaks at all
            parts.append((buf + "\n\n" + para[:limit]).strip())
            buf, para = "", para[limit:]
        if len(buf) + len(para) + 2 > limit and buf:
            parts.append(buf.strip())
            buf = para
        else:
            buf = f"{buf}\n\n{para}" if buf else para
    if buf.strip():
        parts.append(buf.strip())
    return parts


class Summarizer:
    def __init__(self, llm: "BaseChatModel", provider: str, model_name: str) -> None:
        self.llm = llm
        self.provider = provider
        self.model_name = model_name
    def _call(self, system: str, user: str) -> str:
        from langchain_core.messages import HumanMessage, SystemMessage

        try:
            response = self.llm.invoke([SystemMessage(content=system), HumanMessage(content=user)])
        except Exception as exc:
            raise to_llm_error(exc, self.provider) from exc
        return content_to_text(response.content).strip()

    def summarize(
        self,
        pages: list[PageText],
        style_key: str = "medium",
        doc_name: str = "document",
        progress: ProgressFn | None = None,
    ) -> dict:
        style = SUMMARY_STYLES.get(style_key, SUMMARY_STYLES["medium"])
        report = progress or (lambda *_: None)
        full_text = "\n\n".join(
            (f"[Page {p.number}]\n" if p.number else "") + p.text for p in pages if p.text
        )
        strategy = "single-pass"

        if len(full_text) <= STUFF_CHAR_LIMIT:
            report(0.2, "Reading the document...")
            source = full_text
        else:
            strategy = "map-reduce"
            sections = build_sections(pages)
            notes = self._map(sections, report)
            source = REDUCE_PREFIX + self._collapse(notes, report)

        report(0.9, "Writing the final summary...")
        content = self._call(
            summary_system_prompt(style),
            f"Document title: {doc_name}\n\n<document>\n{source}\n</document>",
        )
        report(1.0, "Done")
        return {
            "style": style.key,
            "content": content,
            "created_at": utc_now(),
            "provider": self.provider,
            "model": self.model_name,
            "strategy": strategy,
        }

    def _map(self, sections: list[str], report: ProgressFn) -> list[str]:
        total = len(sections)
        report(0.05, f"Analysing {total} sections...")
        results: list[str | None] = [None] * total
        done = 0
        with ThreadPoolExecutor(max_workers=MAX_PARALLEL) as pool:
            futures = {pool.submit(self._call, MAP_SYSTEM_PROMPT, s): i for i, s in enumerate(sections)}
            for future in futures:  # preserves ordering of results by index
                idx = futures[future]
                results[idx] = future.result()
                done += 1
                report(0.05 + 0.75 * done / total, f"Analysed section {done}/{total}")
        return [r or "" for r in results]

    def _collapse(self, notes: list[str], report: ProgressFn, depth: int = 0) -> str:
        joined = "\n\n---\n\n".join(notes)
        if len(joined) <= STUFF_CHAR_LIMIT or depth >= 3 or len(notes) <= 1:
            return joined
        report(0.82, "Condensing notes...")
        groups: list[list[str]] = [[]]
        size = 0
        for note in notes:
            if size + len(note) > STUFF_CHAR_LIMIT // 2 and groups[-1]:
                groups.append([])
                size = 0
            groups[-1].append(note)
            size += len(note)
        merged = [self._call(MAP_SYSTEM_PROMPT, REDUCE_PREFIX + "\n\n".join(g)) for g in groups]
        return self._collapse(merged, report, depth + 1)
    def suggest_questions(self, pages: list[PageText], n: int = 5) -> list[str]:
        text = "\n\n".join(p.text for p in pages if p.text)[:20_000]
        raw = self._call(SUGGEST_QUESTIONS_PROMPT.format(n=n), f"<document>\n{text}\n</document>")
        questions = []
        for line in raw.splitlines():
            line = line.strip().lstrip("-*•0123456789.) ").strip()
            if len(line) > 8:
                questions.append(line)
        return questions[:n]
