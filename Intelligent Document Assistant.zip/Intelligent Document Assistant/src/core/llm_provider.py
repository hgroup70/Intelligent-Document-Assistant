"""Chat model / embeddings factory for OpenAI and Gemini.

Imports are done inside the functions so the app still starts if only one
of the provider packages is installed.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from .config import PROVIDER_GEMINI, PROVIDER_OPENAI, ProviderConfig
from .errors import ConfigurationError, LLMServiceError

if TYPE_CHECKING:  # pragma: no cover
    from langchain_core.embeddings import Embeddings
    from langchain_core.language_models import BaseChatModel

logger = logging.getLogger(__name__)

# Reasoning models reject a custom temperature.
_NO_TEMPERATURE_PREFIXES = ("o1", "o3", "o4", "gpt-5")


def get_chat_model(cfg: ProviderConfig, *, streaming: bool = False) -> "BaseChatModel":
    if cfg.provider == PROVIDER_OPENAI:
        try:
            from langchain_openai import ChatOpenAI
        except ImportError as exc:
            raise ConfigurationError("The OpenAI integration is not installed (`pip install langchain-openai`).") from exc
        kwargs: dict = dict(model=cfg.chat_model, api_key=cfg.api_key, timeout=120,
                            max_retries=2, streaming=streaming)
        if not cfg.chat_model.lower().startswith(_NO_TEMPERATURE_PREFIXES):
            kwargs["temperature"] = cfg.temperature
        return ChatOpenAI(**kwargs)

    if cfg.provider == PROVIDER_GEMINI:
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
        except ImportError as exc:
            raise ConfigurationError("The Gemini integration is not installed (`pip install langchain-google-genai`).") from exc
        return ChatGoogleGenerativeAI(model=cfg.chat_model, google_api_key=cfg.api_key,
                                      temperature=cfg.temperature, max_retries=2)

    raise ConfigurationError(f"Unknown LLM provider: {cfg.provider!r}")


def get_embeddings(cfg: ProviderConfig) -> "Embeddings":
    try:
        if cfg.provider == PROVIDER_OPENAI:
            from langchain_openai import OpenAIEmbeddings

            return OpenAIEmbeddings(model=cfg.embedding_model, api_key=cfg.api_key, max_retries=2)
        if cfg.provider == PROVIDER_GEMINI:
            from langchain_google_genai import GoogleGenerativeAIEmbeddings

            return GoogleGenerativeAIEmbeddings(model=cfg.embedding_model, google_api_key=cfg.api_key)
    except ImportError as exc:
        raise ConfigurationError(
            f"The {cfg.provider} integration is not installed. Run `pip install -r requirements.txt`."
        ) from exc
    raise ConfigurationError(f"Unknown LLM provider: {cfg.provider!r}")


def to_llm_error(exc: BaseException, provider: str | None = None) -> LLMServiceError:
    """Translate SDK exceptions into a friendly :class:`LLMServiceError`."""
    if isinstance(exc, LLMServiceError):
        return exc
    name = type(exc).__name__.lower()
    text = str(exc).lower()
    label = {"openai": "OpenAI", "gemini": "Gemini"}.get(provider or "", "The AI provider")

    def has(*needles: str) -> bool:
        return any(n in text or n in name for n in needles)

    if has("authentication", "invalid api key", "incorrect api key", "api key not valid",
           "api_key_invalid", "401", "permission denied", "unauthenticated"):
        msg = f"{label} rejected the API key. Check the key in your `.env` file or the sidebar."
    elif has("insufficient_quota", "quota", "billing"):
        msg = f"{label} reports the account has no remaining quota. Check your plan and billing."
    elif has("ratelimit", "rate limit", "429", "resource_exhausted", "too many requests"):
        msg = f"{label} is rate-limiting requests. Wait a few seconds and try again."
    elif has("context_length", "maximum context", "too many tokens", "token limit"):
        msg = "The request was too long for the selected model. Try a shorter summary or fewer sources."
    elif has("not_found", "notfound", "404", "does not exist", "model not found"):
        msg = f"{label} could not find the configured model. Check the model name in settings."
    elif has("timeout", "timed out"):
        msg = f"{label} took too long to respond. Please try again."
    elif has("connection", "network", "dns", "ssl"):
        msg = f"Could not reach {label}. Check your internet connection."
    elif has("safety", "blocked"):
        msg = f"{label} blocked the response for safety reasons. Try rephrasing."
    else:
        msg = f"{label} returned an unexpected error. Please try again."
    logger.exception("LLM call failed", exc_info=exc)
    return LLMServiceError(msg, detail=f"{type(exc).__name__}: {exc}")


def content_to_text(content) -> str:
    """Normalize an AIMessage ``content`` (str or list of parts) to text."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for part in content:
            if isinstance(part, str):
                parts.append(part)
            elif isinstance(part, dict) and part.get("type", "text") == "text":
                parts.append(part.get("text", ""))
        return "".join(parts)
    return str(content or "")
