"""Left sidebar: upload, document list, settings."""

from __future__ import annotations

import streamlit as st

from src.core.config import PROVIDER_GEMINI, PROVIDER_LABELS, PROVIDER_OPENAI
from src.core.document_processor import SUPPORTED_EXTENSIONS
from src.core.errors import AppError
from src.core.service import DocumentService
from src.ui import state
from src.ui.formatting import human_size

_KEY_HELP = {
    PROVIDER_OPENAI: "Get a key at https://platform.openai.com/api-keys",
    PROVIDER_GEMINI: "Get a key at https://aistudio.google.com/app/apikey",
}


def render_sidebar(svc: DocumentService) -> None:
    with st.sidebar:
        st.markdown(
            '<div class="brand"><span class="brand-logo"></span><div>'
            '<div class="brand-title">Document Assistant</div>'
            '<div class="brand-sub">Summarize &amp; chat with your files</div></div></div>',
            unsafe_allow_html=True,
        )
        if st.session_state.username:
            c1, c2 = st.columns([3, 2])
            c1.caption(f"Signed in as **{st.session_state.username}**")
            if c2.button("Sign out", width="stretch"):
                for key in list(st.session_state.keys()):
                    del st.session_state[key]
                st.rerun()

        state.show_flash()
        _render_upload(svc)
        _render_documents(svc)
        _render_settings()
        s = state.settings()
        st.caption(
            f"Limits: {s.max_file_size_mb} MB | {s.max_pages} pages per file | "
            f"{s.max_documents} documents"
        )
def _render_upload(svc: DocumentService) -> None:
    st.subheader("Upload")
    files = st.file_uploader(
        "Drag and drop PDF or text files",
        type=[e.lstrip(".") for e in sorted(SUPPORTED_EXTENSIONS)],
        accept_multiple_files=True,
        key=f"uploader_{st.session_state.uploader_key}",
        help="PDF, TXT and Markdown files are supported. Scanned PDFs need OCR first.",
    )
    if not files:
        return

    cfg = state.provider_config()
    last_id = None
    for file in files:
        with st.status(f"Processing **{file.name}**...", expanded=True) as status:
            bar = st.progress(0.0)

            def progress(fraction: float, message: str) -> None:
                bar.progress(min(max(fraction, 0.0), 1.0), text=message)

            try:
                record, duplicate, index_error = svc.ingest(file.name, file.getvalue(), cfg, progress)
            except AppError as exc:
                status.update(label=f"{file.name}", state="error")
                state.flash("error", f"**{file.name}:** {exc.user_message}")
                continue
            except Exception as exc:  # never crash the app on upload
                status.update(label=f"{file.name}", state="error")
                state.flash("error", f"**{file.name}:** unexpected error ({type(exc).__name__}).")
                continue

            last_id = record.id
            if duplicate:
                status.update(label=f"{file.name} already uploaded", state="complete")
                state.flash("info", f"**{file.name}** is already in your library - switched to it.")
            elif index_error:
                status.update(label=f"{file.name} (not indexed)", state="complete")
                state.flash("warning", f"**{file.name}** was saved, but indexing failed: {index_error} "
                                       "It will be retried when you ask a question.")
            else:
                status.update(label=f"{file.name}", state="complete")
                note = "" if cfg else " Add an API key in Settings to summarize and ask questions."
                state.flash("success", f"**{file.name}** is ready.{note}")
                for warning in record.warnings:
                    state.flash("warning", f"**{file.name}:** {warning}")

    if last_id:
        state.select_document(last_id)
    st.session_state.uploader_key += 1  # clears the uploader widget
    st.rerun()
def _render_documents(svc: DocumentService) -> None:
    docs = svc.workspace.list_documents()
    st.subheader(f"Documents ({len(docs)})")
    if not docs:
        st.caption("No documents yet. Upload one above to get started.")
        return

    active = st.session_state.active_doc_id
    for doc in docs:
        col_btn, col_del = st.columns([6, 1], vertical_alignment="center")
        is_active = doc.id == active
        if col_btn.button(
            doc.name,
            key=f"select_{doc.id}",
            type="primary" if is_active else "secondary",
            width="stretch",
            help=f"{human_size(doc.size_bytes)} | uploaded {doc.uploaded_at[:16].replace('T', ' ')} UTC",
        ):
            state.select_document(doc.id)
            st.rerun()
        with col_del.popover(":material/delete:", help="Delete document"):
            st.markdown(f"Delete **{doc.name}**?")
            st.caption("This removes the file, its summaries, index and conversations.")
            if st.button("Delete", key=f"delete_{doc.id}", type="primary", width="stretch"):
                svc.delete(doc.id)
                st.session_state.conversations.pop(f"doc:{doc.id}", None)
                st.session_state.conversations.pop("all", None)
                if is_active:
                    st.session_state.active_doc_id = None
                state.flash("success", f"Deleted **{doc.name}**.")
                st.rerun()
def _render_settings() -> None:
    s = state.settings()
    with st.expander("Settings", expanded=state.provider_config() is None):
        configured = s.configured_providers()
        options = [PROVIDER_OPENAI, PROVIDER_GEMINI]

        def label(p: str) -> str:
            has_key = p in configured or bool(st.session_state.api_keys.get(p))
            return PROVIDER_LABELS[p] if has_key else f"{PROVIDER_LABELS[p]} (no key)"

        provider = st.selectbox(
            "AI provider", options, index=options.index(st.session_state.provider),
            format_func=label,
            help="Each provider uses its own embeddings, so switching "
                 "re-indexes documents on first use.",
        )
        if provider != st.session_state.provider:
            st.session_state.provider = provider
            st.rerun()

        if provider not in configured or st.session_state.api_keys.get(provider):
            key = st.text_input(
                f"{PROVIDER_LABELS[provider]} API key",
                value=st.session_state.api_keys.get(provider, ""),
                type="password",
                help=_KEY_HELP[provider] + " - kept only in this browser session.",
                placeholder="Paste your key...",
            )
            if key.strip() != st.session_state.api_keys.get(provider, ""):
                st.session_state.api_keys[provider] = key.strip()
                st.rerun()
            if not key:
                st.caption(f"No key in `.env`. {_KEY_HELP[provider]}")

        default_chat, embedding = s.default_models(provider)
        model = st.text_input(
            "Chat model", value=st.session_state.chat_models.get(provider, default_chat),
            help=f"Embeddings: `{embedding}` (set in .env)",
        )
        st.session_state.chat_models[provider] = model.strip() or default_chat

        st.session_state.temperature = st.slider(
            "Creativity (temperature)", 0.0, 1.0, float(st.session_state.temperature), 0.05,
            help="Lower = more factual and consistent. Recommended: 0.0-0.3.",
        )
        st.session_state.retrieval_k = st.slider(
            "Sources per answer", 2, 12, int(st.session_state.retrieval_k),
            help="How many document excerpts are retrieved to answer each question.",
        )
