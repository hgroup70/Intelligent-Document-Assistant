"""Glue between the UI and the core modules (storage, indexing, LLM calls)."""

from __future__ import annotations

import logging
from collections.abc import Callable

from .config import ProviderConfig, Settings
from .document_processor import extract_document
from .errors import AppError, ConfigurationError
from .llm_provider import get_chat_model, get_embeddings
from .qa_engine import QAEngine
from .storage import DocumentRecord, Workspace
from .summarizer import Summarizer
from .vector_store import VectorStoreManager, chunk_pages

logger = logging.getLogger(__name__)
ProgressFn = Callable[[float, str], None]


class DocumentService:
    def __init__(self, settings: Settings, workspace: Workspace,
                 vectors: VectorStoreManager | None = None) -> None:
        self.settings = settings
        self.workspace = workspace
        self.vectors = vectors or VectorStoreManager()

    # documents
    def ingest(
        self,
        name: str,
        data: bytes,
        cfg: ProviderConfig | None,
        progress: ProgressFn | None = None,
    ) -> tuple[DocumentRecord, bool, str | None]:
        """Extract, store and (if a provider is configured) index a file.

        Returns ``(record, is_duplicate, index_error)``. A failed indexing step
        does not lose the document: it is retried on the first question.
        """
        report = progress or (lambda *_: None)
        if len(self.workspace.list_documents()) >= self.settings.max_documents:
            raise AppError(
                f"You can store up to {self.settings.max_documents} documents. "
                "Delete one before uploading another."
            )
        report(0.05, "Extracting text...")
        extracted = extract_document(
            name, data,
            max_size_mb=self.settings.max_file_size_mb,
            max_pages=self.settings.max_pages,
        )
        existing = self.workspace.find_by_hash(extracted.sha256)
        if existing:
            return existing, True, None

        record = self.workspace.add_document(extracted)
        report(0.3, f"Extracted {extracted.word_count:,} words")
        index_error = None
        if cfg is not None:
            try:
                self.ensure_index(record, cfg, lambda f, m: report(0.3 + 0.7 * f, m))
            except AppError as exc:
                logger.warning("Indexing failed for %s; will retry lazily", record.name)
                index_error = exc.user_message
        report(1.0, "Ready")
        return record, False, index_error

    def delete(self, doc_id: str) -> None:
        self.vectors.evict(self.workspace.index_root(doc_id))
        self.workspace.delete_document(doc_id)

    # indexing
    def is_indexed(self, doc_id: str, cfg: ProviderConfig) -> bool:
        return self.vectors.has_index(self.workspace.index_root(doc_id), cfg.embedding_signature)

    def ensure_index(self, record: DocumentRecord, cfg: ProviderConfig,
                     progress: ProgressFn | None = None):
        embeddings = get_embeddings(cfg)

        def factory():
            return chunk_pages(
                self.workspace.load_pages(record.id),
                doc_id=record.id,
                doc_name=record.name,
                chunk_size=self.settings.chunk_size,
                chunk_overlap=self.settings.chunk_overlap,
            )

        return self.vectors.get_or_build(
            self.workspace.index_root(record.id), cfg.embedding_signature,
            embeddings, factory, progress,
        )

    # Q&A
    def build_qa_engine(
        self,
        records: list[DocumentRecord],
        cfg: ProviderConfig,
        *,
        k: int,
        progress: ProgressFn | None = None,
    ) -> QAEngine:
        if not records:
            raise ConfigurationError("Select at least one document to ask questions about.")
        stores = []
        for i, record in enumerate(records):
            if progress and not self.is_indexed(record.id, cfg):
                progress(i / len(records), f"Indexing {record.name}...")
            stores.append(self.ensure_index(record, cfg))

        def retriever(query: str, top_k: int):
            return self.vectors.search(stores, query, top_k)

        return QAEngine(
            get_chat_model(cfg, streaming=True),
            retriever,
            provider=cfg.provider,
            k=k,
            max_history_turns=self.settings.max_history_turns,
        )

    # summaries
    def summarize(self, record: DocumentRecord, style: str, cfg: ProviderConfig,
                  progress: ProgressFn | None = None) -> dict:
        summarizer = Summarizer(get_chat_model(cfg), cfg.provider, cfg.chat_model)
        summary = summarizer.summarize(
            self.workspace.load_pages(record.id), style, record.name, progress
        )
        self.workspace.save_summary(record.id, style, summary)
        return summary

    def suggest_questions(self, record: DocumentRecord, cfg: ProviderConfig) -> list[str]:
        summarizer = Summarizer(get_chat_model(cfg), cfg.provider, cfg.chat_model)
        questions = summarizer.suggest_questions(self.workspace.load_pages(record.id))
        self.workspace.save_suggested_questions(record.id, questions)
        return questions
