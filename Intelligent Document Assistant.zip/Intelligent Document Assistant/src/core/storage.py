"""File-based storage, one folder per workspace.

data/workspaces/<id>/
    documents.json
    docs/<doc_id>/pages.json, summaries.json, questions.json
    indexes/<doc_id>/<provider>__<embedding model>/
    conversations/<scope>/<conv_id>.json
"""

from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
import threading
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .document_processor import ExtractedDocument, PageText

_lock = threading.RLock()
_SAFE_ID = re.compile(r"[^A-Za-z0-9_\-]")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def safe_id(value: str) -> str:
    cleaned = _SAFE_ID.sub("_", value)[:64]
    return cleaned or "default"


def _atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".tmp-", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def _read_json(path: Path, default: Any) -> Any:
    try:
        with path.open(encoding="utf-8") as fh:
            return json.load(fh)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def cleanup_stale_workspaces(root: Path, *, prefix: str = "anon_", max_age_days: int = 7) -> int:
    """Delete anonymous workspaces not touched for ``max_age_days``."""
    import time

    base = Path(root) / "workspaces"
    if not base.exists():
        return 0
    cutoff = time.time() - max_age_days * 86400
    removed = 0
    for ws in base.iterdir():
        if not (ws.is_dir() and ws.name.startswith(prefix)):
            continue
        newest = max((p.stat().st_mtime for p in ws.rglob("*")), default=ws.stat().st_mtime)
        if newest < cutoff:
            shutil.rmtree(ws, ignore_errors=True)
            removed += 1
    return removed
# Records
@dataclass
class DocumentRecord:
    id: str
    name: str
    file_type: str
    size_bytes: int
    sha256: str
    char_count: int
    word_count: int
    page_count: int | None
    uploaded_at: str
    warnings: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "DocumentRecord":
        known = {f for f in cls.__dataclass_fields__}  # tolerate extra keys
        return cls(**{k: v for k, v in data.items() if k in known})


@dataclass
class ChatMessage:
    role: str  # "user" | "assistant"
    content: str
    timestamp: str = field(default_factory=utc_now)
    citations: list[dict] = field(default_factory=list)
    model: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "ChatMessage":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})


@dataclass
class Conversation:
    id: str
    scope: str  # "doc:<id>" or "all"
    title: str
    created_at: str
    updated_at: str
    messages: list[ChatMessage] = field(default_factory=list)

    def to_dict(self) -> dict:
        data = asdict(self)
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "Conversation":
        return cls(
            id=data["id"],
            scope=data["scope"],
            title=data.get("title", "Conversation"),
            created_at=data.get("created_at", utc_now()),
            updated_at=data.get("updated_at", utc_now()),
            messages=[ChatMessage.from_dict(m) for m in data.get("messages", [])],
        )
# Workspace
class Workspace:
    """All persistent data belonging to one user / session."""

    def __init__(self, root: Path, workspace_id: str) -> None:
        self.id = safe_id(workspace_id)
        self.root = Path(root) / "workspaces" / self.id
        self.root.mkdir(parents=True, exist_ok=True)

    # paths
    @property
    def _registry_path(self) -> Path:
        return self.root / "documents.json"

    def doc_dir(self, doc_id: str) -> Path:
        return self.root / "docs" / safe_id(doc_id)

    def index_root(self, doc_id: str) -> Path:
        return self.root / "indexes" / safe_id(doc_id)

    def _conv_dir(self, scope: str) -> Path:
        return self.root / "conversations" / safe_id(scope.replace(":", "_"))

    # documents
    def list_documents(self) -> list[DocumentRecord]:
        with _lock:
            raw = _read_json(self._registry_path, [])
        docs = [DocumentRecord.from_dict(d) for d in raw]
        return sorted(docs, key=lambda d: d.uploaded_at, reverse=True)

    def get_document(self, doc_id: str) -> DocumentRecord | None:
        return next((d for d in self.list_documents() if d.id == doc_id), None)

    def find_by_hash(self, sha256: str) -> DocumentRecord | None:
        return next((d for d in self.list_documents() if d.sha256 == sha256), None)

    def add_document(self, extracted: ExtractedDocument) -> DocumentRecord:
        record = DocumentRecord(
            id=uuid.uuid4().hex[:12],
            name=extracted.name,
            file_type=extracted.file_type,
            size_bytes=extracted.size_bytes,
            sha256=extracted.sha256,
            char_count=extracted.char_count,
            word_count=extracted.word_count,
            page_count=extracted.page_count,
            uploaded_at=utc_now(),
            warnings=list(extracted.warnings),
        )
        _atomic_write_json(
            self.doc_dir(record.id) / "pages.json",
            [{"number": p.number, "text": p.text} for p in extracted.pages],
        )
        with _lock:
            raw = _read_json(self._registry_path, [])
            raw.append(asdict(record))
            _atomic_write_json(self._registry_path, raw)
        return record

    def load_pages(self, doc_id: str) -> list[PageText]:
        raw = _read_json(self.doc_dir(doc_id) / "pages.json", [])
        return [PageText(number=p.get("number"), text=p.get("text", "")) for p in raw]

    def delete_document(self, doc_id: str) -> None:
        with _lock:
            raw = _read_json(self._registry_path, [])
            raw = [d for d in raw if d.get("id") != doc_id]
            _atomic_write_json(self._registry_path, raw)
        shutil.rmtree(self.doc_dir(doc_id), ignore_errors=True)
        shutil.rmtree(self.index_root(doc_id), ignore_errors=True)
        shutil.rmtree(self._conv_dir(f"doc:{doc_id}"), ignore_errors=True)

    # summaries & suggested questions
    def get_summaries(self, doc_id: str) -> dict[str, dict]:
        return _read_json(self.doc_dir(doc_id) / "summaries.json", {})

    def save_summary(self, doc_id: str, style: str, summary: dict) -> None:
        with _lock:
            summaries = self.get_summaries(doc_id)
            summaries[style] = summary
            _atomic_write_json(self.doc_dir(doc_id) / "summaries.json", summaries)

    def get_suggested_questions(self, doc_id: str) -> list[str]:
        return _read_json(self.doc_dir(doc_id) / "questions.json", [])

    def save_suggested_questions(self, doc_id: str, questions: list[str]) -> None:
        _atomic_write_json(self.doc_dir(doc_id) / "questions.json", questions)

    # conversations
    def list_conversations(self, scope: str | None = None) -> list[Conversation]:
        dirs = [self._conv_dir(scope)] if scope else list((self.root / "conversations").glob("*"))
        convs: list[Conversation] = []
        for d in dirs:
            for path in d.glob("*.json"):
                data = _read_json(path, None)
                if data:
                    convs.append(Conversation.from_dict(data))
        return sorted(convs, key=lambda c: c.updated_at, reverse=True)

    def new_conversation(self, scope: str, title: str = "New conversation") -> Conversation:
        now = utc_now()
        return Conversation(id=uuid.uuid4().hex[:12], scope=scope, title=title,
                            created_at=now, updated_at=now)

    def latest_conversation(self, scope: str) -> Conversation:
        convs = self.list_conversations(scope)
        return convs[0] if convs else self.new_conversation(scope)

    def load_conversation(self, scope: str, conv_id: str) -> Conversation | None:
        data = _read_json(self._conv_dir(scope) / f"{safe_id(conv_id)}.json", None)
        return Conversation.from_dict(data) if data else None

    def save_conversation(self, conv: Conversation) -> None:
        if not conv.messages:
            return  # never persist empty conversations
        conv.updated_at = utc_now()
        _atomic_write_json(self._conv_dir(conv.scope) / f"{safe_id(conv.id)}.json", conv.to_dict())

    def delete_conversation(self, scope: str, conv_id: str) -> None:
        (self._conv_dir(scope) / f"{safe_id(conv_id)}.json").unlink(missing_ok=True)
