"""Export summaries and conversations to Markdown, JSON and PDF."""

from __future__ import annotations

import io
import json
import re
from datetime import datetime
from html import escape
from pathlib import Path

from .storage import Conversation, DocumentRecord
# Markdown
def _fmt_ts(ts: str) -> str:
    try:
        return datetime.fromisoformat(ts).strftime("%Y-%m-%d %H:%M UTC")
    except ValueError:
        return ts


def summary_to_markdown(record: DocumentRecord, summary: dict) -> str:
    meta = [
        f"- **Source:** {record.name}",
        f"- **Summary length:** {summary.get('style', '').title()}",
        f"- **Generated:** {_fmt_ts(summary.get('created_at', ''))}",
        f"- **Model:** {summary.get('provider', '')} / {summary.get('model', '')}",
    ]
    if record.page_count:
        meta.insert(1, f"- **Pages:** {record.page_count}")
    return f"# Summary - {record.name}\n\n" + "\n".join(meta) + "\n\n---\n\n" + summary["content"].strip() + "\n"


def conversation_to_markdown(conv: Conversation, doc_names: list[str]) -> str:
    lines = [
        f"# {conv.title}",
        "",
        f"- **Documents:** {', '.join(doc_names) or 'n/a'}",
        f"- **Started:** {_fmt_ts(conv.created_at)}",
        f"- **Last updated:** {_fmt_ts(conv.updated_at)}",
        "",
        "---",
        "",
    ]
    for msg in conv.messages:
        if msg.role == "user":
            lines += [f"### Question", "", msg.content, ""]
        else:
            lines += ["### Answer", "", msg.content, ""]
            cited = [c for c in msg.citations if c.get("cited")] or msg.citations
            if cited:
                lines.append("**Sources:**")
                lines.append("")
                for c in cited:
                    where = f"p. {c['page']}" if c.get("page") else f"chunk {c.get('chunk_id')}"
                    excerpt = " ".join(c.get("excerpt", "").split())[:300]
                    lines.append(f"- [{c['index']}] *{c.get('doc_name')}*, {where}: '{excerpt}...'")
                lines.append("")
    return "\n".join(lines)


def conversation_to_json(conv: Conversation) -> str:
    return json.dumps(conv.to_dict(), ensure_ascii=False, indent=2)
# PDF (reportlab)
_FONT_CANDIDATES = [
    ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ("/usr/share/fonts/dejavu/DejaVuSans.ttf", "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf"),
    ("/Library/Fonts/Arial Unicode.ttf", "/Library/Fonts/Arial Unicode.ttf"),
    ("C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"),
]
_FONTS: tuple[str, str] | None = None


def _register_fonts() -> tuple[str, str]:
    """Use a Unicode TTF font when one is available, else Helvetica."""
    global _FONTS
    if _FONTS:
        return _FONTS
    from reportlab.lib.fonts import addMapping
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    bundled = Path(__file__).resolve().parents[2] / "assets" / "fonts"
    candidates = [(str(bundled / "DejaVuSans.ttf"), str(bundled / "DejaVuSans-Bold.ttf"))] + _FONT_CANDIDATES
    for regular, bold in candidates:
        if Path(regular).exists() and Path(bold).exists():
            try:
                pdfmetrics.registerFont(TTFont("DocSans", regular))
                pdfmetrics.registerFont(TTFont("DocSans-Bold", bold))
                addMapping("DocSans", 0, 0, "DocSans")
                addMapping("DocSans", 1, 0, "DocSans-Bold")
                addMapping("DocSans", 0, 1, "DocSans")
                addMapping("DocSans", 1, 1, "DocSans-Bold")
                _FONTS = ("DocSans", "DocSans-Bold")
                return _FONTS
            except Exception:
                continue
    _FONTS = ("Helvetica", "Helvetica-Bold")
    return _FONTS


_BOLD = re.compile(r"\*\*(.+?)\*\*")
_ITALIC = re.compile(r"(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?!\*)")
_CODE = re.compile(r"`([^`]+)`")


def _inline(text: str, font: str) -> str:
    """Convert inline Markdown to reportlab's mini-HTML."""
    text = escape(text, quote=False)
    text = _BOLD.sub(r"<b>\1</b>", text)
    text = _ITALIC.sub(r"<i>\1</i>", text)
    text = _CODE.sub(r'<font face="Courier">\1</font>', text)
    if font == "Helvetica":  # core fonts are Latin-1 only
        text = text.encode("latin-1", "replace").decode("latin-1")
    return text


def markdown_to_pdf(markdown: str, title: str = "Document") -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import HRFlowable, ListFlowable, ListItem, Paragraph, SimpleDocTemplate, Spacer

    regular, bold = _register_fonts()
    base = getSampleStyleSheet()
    accent = colors.HexColor("#4F46E5")
    styles = {
        "body": ParagraphStyle("body", parent=base["BodyText"], fontName=regular, fontSize=10.5,
                               leading=15, alignment=TA_LEFT, spaceAfter=6),
        "h1": ParagraphStyle("h1", parent=base["Heading1"], fontName=bold, fontSize=18, leading=22,
                             textColor=accent, spaceAfter=10),
        "h2": ParagraphStyle("h2", parent=base["Heading2"], fontName=bold, fontSize=13.5, leading=17,
                             textColor=accent, spaceBefore=10, spaceAfter=6),
        "h3": ParagraphStyle("h3", parent=base["Heading3"], fontName=bold, fontSize=11.5, leading=15,
                             spaceBefore=8, spaceAfter=4),
    }

    story: list = []
    bullets: list = []
    ordered = False

    def flush_bullets() -> None:
        nonlocal bullets
        if bullets:
            story.append(ListFlowable(
                [ListItem(b, leftIndent=12) for b in bullets],
                bulletType="1" if ordered else "bullet",
                start="1" if ordered else "•",
                leftIndent=14, bulletFontName=regular, bulletFontSize=9,
            ))
            story.append(Spacer(1, 4))
            bullets = []

    paragraph: list[str] = []

    def flush_paragraph() -> None:
        nonlocal paragraph
        if paragraph:
            story.append(Paragraph(_inline(" ".join(paragraph), regular), styles["body"]))
            paragraph = []

    for raw in markdown.splitlines():
        line = raw.rstrip()
        stripped = line.strip()
        bullet = re.match(r"^\s*[-*+•]\s+(.*)", line)
        number = re.match(r"^\s*\d+[.)]\s+(.*)", line)
        if not stripped:
            flush_paragraph()
            continue
        if stripped in {"---", "***", "___"}:
            flush_paragraph(); flush_bullets()
            story.append(HRFlowable(width="100%", color=colors.HexColor("#E5E7EB"), spaceBefore=4, spaceAfter=8))
        elif stripped.startswith("#"):
            flush_paragraph(); flush_bullets()
            level = min(len(stripped) - len(stripped.lstrip("#")), 3)
            story.append(Paragraph(_inline(stripped.lstrip("#").strip(), regular), styles[f"h{level}"]))
        elif bullet or number:
            flush_paragraph()
            is_ordered = bool(number) and not bullet
            if bullets and is_ordered != ordered:
                flush_bullets()
            ordered = is_ordered
            text = (bullet or number).group(1)  # type: ignore[union-attr]
            bullets.append(Paragraph(_inline(text, regular), styles["body"]))
        else:
            flush_bullets()
            paragraph.append(stripped)
    flush_paragraph(); flush_bullets()

    buffer = io.BytesIO()

    def footer(canvas, doc) -> None:
        canvas.saveState()
        canvas.setFont(regular, 8)
        canvas.setFillColor(colors.HexColor("#6B7280"))
        canvas.drawString(2 * cm, 1.2 * cm, title[:90])
        canvas.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"Page {doc.page}")
        canvas.restoreState()

    doc = SimpleDocTemplate(buffer, pagesize=A4, title=title, leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=2 * cm, bottomMargin=2 * cm)
    doc.build(story or [Paragraph("(empty)", styles["body"])], onFirstPage=footer, onLaterPages=footer)
    return buffer.getvalue()


def safe_filename(name: str, suffix: str) -> str:
    stem = re.sub(r"[^\w\-]+", "_", Path(name).stem).strip("_") or "document"
    return f"{stem[:60]}{suffix}"
