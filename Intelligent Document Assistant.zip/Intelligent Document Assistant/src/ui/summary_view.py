"""Summary tab: choose a length, generate, view, download."""

from __future__ import annotations

import streamlit as st

from src.core.errors import AppError
from src.core.export import markdown_to_pdf, safe_filename, summary_to_markdown
from src.core.prompts import SUMMARY_STYLES
from src.core.service import DocumentService
from src.core.storage import DocumentRecord
from src.ui import state
from src.ui.formatting import human_time


def render_summary(svc: DocumentService, doc: DocumentRecord) -> None:
    summaries = svc.workspace.get_summaries(doc.id)
    keys = list(SUMMARY_STYLES)

    top_left, top_right = st.columns([3, 2], vertical_alignment="bottom")
    with top_left:
        style = st.segmented_control(
            "Summary length",
            keys,
            default=st.session_state.summary_style,
            format_func=lambda k: SUMMARY_STYLES[k].label,
            key=f"style_picker_{doc.id}",
        ) or st.session_state.summary_style
        st.session_state.summary_style = style
        st.caption(SUMMARY_STYLES[style].description)

    existing = summaries.get(style)
    cfg = state.provider_config()
    with top_right:
        clicked = st.button(
            "Regenerate" if existing else "Generate summary",
            type="secondary" if existing else "primary",
            width="stretch",
            disabled=cfg is None,
            help=None if cfg else "Add an API key in Settings first.",
        )

    if clicked and cfg:
        with st.status(f"Generating {SUMMARY_STYLES[style].label.lower()} summary...", expanded=True) as status:
            bar = st.progress(0.0)
            try:
                existing = svc.summarize(doc, style, cfg,
                                         lambda f, m: bar.progress(min(f, 1.0), text=m))
                status.update(label="Summary ready", state="complete", expanded=False)
            except AppError as exc:
                status.update(label="Summary failed", state="error")
                st.error(exc.user_message)
                return

    if not existing:
        _empty_state(cfg is not None)
        return

    with st.container(border=True):
        st.markdown(existing["content"])
        st.markdown(
            f'<div class="summary-meta">Generated {human_time(existing.get("created_at", ""))} | '
            f'{existing.get("provider", "")} / {existing.get("model", "")} | '
            f'{existing.get("strategy", "")}</div>',
            unsafe_allow_html=True,
        )

    md = summary_to_markdown(doc, existing)
    c1, c2, c3 = st.columns([1, 1, 2])
    c1.download_button("Markdown", md, file_name=safe_filename(doc.name, f"_summary_{style}.md"),
                       mime="text/markdown", width="stretch")
    try:
        pdf_bytes = _pdf(md, doc.name)
        c2.download_button("PDF", pdf_bytes, file_name=safe_filename(doc.name, f"_summary_{style}.pdf"),
                           mime="application/pdf", width="stretch")
    except Exception:  # PDF export is best-effort
        c2.button("PDF", disabled=True, help="PDF export unavailable", width="stretch")
    if c3.button("Ask about this document", width="stretch"):
        state.navigate(state.VIEW_CHAT)
        st.rerun()


@st.cache_data(show_spinner=False, max_entries=32)
def _pdf(markdown: str, title: str) -> bytes:
    return markdown_to_pdf(markdown, title=f"Summary - {title}")


def _empty_state(has_provider: bool) -> None:
    with st.container(border=True):
        st.markdown("#### No summary yet")
        if has_provider:
            st.markdown(
                "Pick a length above and click **Generate summary**. You'll get:\n"
                "- a short **overview** paragraph\n- bullet-point **key insights**\n"
                "- **main ideas** and **conclusions** (Medium / Detailed)"
            )
        else:
            st.info("Add an OpenAI or Gemini API key in **Settings** to generate summaries.")
