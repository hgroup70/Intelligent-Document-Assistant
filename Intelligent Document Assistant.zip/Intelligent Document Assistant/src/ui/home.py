"""Welcome screen (no documents yet) and the active-document header."""

from __future__ import annotations

import streamlit as st

from src.core.config import PROVIDER_LABELS
from src.core.prompts import GENERIC_EXAMPLE_QUESTIONS
from src.core.storage import DocumentRecord
from src.ui import state
from src.ui.formatting import human_size, human_time

_FEATURES = [
    ("Upload", "Drop PDFs or text files into the sidebar. Text is extracted page by page."),
    ("Summarize", "Short, medium or detailed summaries with key points and conclusions."),
    ("Ask", "Chat with the document. Answers point to the passages and pages they come from."),
    ("Keep", "Conversations are saved automatically. Export summaries and chats as PDF or Markdown."),
]


def render_welcome() -> None:
    st.markdown(
        '<div class="hero"><h1>Intelligent Document Assistant</h1>'
        "<p>Upload a PDF or text file to get a summary and ask questions about it. "
        "Answers come from the document only and show where they were found.</p></div>",
        unsafe_allow_html=True,
    )
    cols = st.columns(len(_FEATURES))
    for col, (title, text) in zip(cols, _FEATURES):
        col.markdown(
            '<div class="feature-card">'
            f"<h4>{title}</h4><p>{text}</p></div>",
            unsafe_allow_html=True,
        )

    st.write("")
    left, right = st.columns(2, gap="large")
    with left:
        st.markdown("#### Getting started")
        st.markdown(
            "1. Add your **OpenAI** or **Gemini** API key in `.env` or in **Settings** (sidebar).\n"
            "2. **Upload** one or more PDF / TXT / Markdown files in the sidebar.\n"
            "3. Open **Summary** and pick a length, or go to **Ask questions**.\n"
            "4. Each document keeps its own chat history."
        )
        if state.provider_config() is None:
            st.warning("No API key found. Add one in **Settings** in the sidebar.")
    with right:
        st.markdown("#### Example questions")
        for q in GENERIC_EXAMPLE_QUESTIONS:
            st.markdown(f"- *{q}*")


def render_doc_header(doc: DocumentRecord) -> None:
    kind = "PDF" if doc.file_type == "pdf" else "Text"
    cfg = state.provider_config()
    model = f"{PROVIDER_LABELS[cfg.provider]} | {cfg.chat_model}" if cfg else "No model configured"
    st.markdown(
        f'<div class="doc-title">{_esc(doc.name)}</div>'
        f'<div class="doc-meta"><span class="pill">{kind}</span><span class="pill">{_esc(model)}</span>'
        f"Uploaded {human_time(doc.uploaded_at)}</div>",
        unsafe_allow_html=True,
    )
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Pages", doc.page_count if doc.page_count else "-")
    c2.metric("Words", f"{doc.word_count:,}")
    c3.metric("Characters", f"{doc.char_count:,}")
    c4.metric("File size", human_size(doc.size_bytes))
    if doc.warnings:
        with st.expander(f"{len(doc.warnings)} extraction note(s)"):
            for w in doc.warnings:
                st.caption(f"• {w}")


def _esc(text: str) -> str:
    import html

    return html.escape(text)
