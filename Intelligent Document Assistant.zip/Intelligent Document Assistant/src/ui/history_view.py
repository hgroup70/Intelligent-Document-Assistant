"""Saved sessions tab: browse, reopen, export and delete past conversations."""

from __future__ import annotations

import streamlit as st

from src.core.export import conversation_to_json, conversation_to_markdown, safe_filename
from src.core.service import DocumentService
from src.ui import state
from src.ui.formatting import human_time


def render_history(svc: DocumentService) -> None:
    docs = {d.id: d for d in svc.workspace.list_documents()}
    convs = svc.workspace.list_conversations()
    if not convs:
        st.info("No saved sessions yet. Conversations are saved automatically as you ask questions.")
        return

    filter_options = ["All sessions"] + [f"doc:{d.id}" for d in docs.values()] + ["all"]
    labels = {"All sessions": "All sessions", "all": "Across all documents",
              **{f"doc:{d.id}": d.name for d in docs.values()}}
    choice = st.selectbox("Filter", filter_options, format_func=lambda k: labels.get(k, k))
    if choice != "All sessions":
        convs = [c for c in convs if c.scope == choice]

    st.caption(f"{len(convs)} session(s)")
    for conv in convs:
        if conv.scope == "all":
            scope_label, names = "All documents", [d.name for d in docs.values()]
        else:
            doc = docs.get(conv.scope.removeprefix("doc:"))
            scope_label = f"{doc.name}" if doc else "(deleted document)"
            names = [doc.name] if doc else []
        questions = sum(1 for m in conv.messages if m.role == "user")

        with st.container(border=True):
            st.markdown(f"**{conv.title}**")
            st.caption(f"{scope_label} | {questions} question(s) | last active {human_time(conv.updated_at)}")
            c1, c2, c3, c4 = st.columns(4)
            if c1.button("Open", key=f"open_{conv.id}", width="stretch",
                         disabled=conv.scope != "all" and not names):
                state.set_conversation(conv)
                if conv.scope == "all":
                    st.session_state.search_all_docs = True
                else:
                    state.select_document(conv.scope.removeprefix("doc:"))
                    st.session_state.search_all_docs = False
                state.navigate(state.VIEW_CHAT)
                st.rerun()
            c2.download_button("Markdown", conversation_to_markdown(conv, names),
                               file_name=safe_filename(conv.title, ".md"), mime="text/markdown",
                               key=f"md_{conv.id}", width="stretch")
            c3.download_button("JSON", conversation_to_json(conv),
                               file_name=safe_filename(conv.title, ".json"), mime="application/json",
                               key=f"json_{conv.id}", width="stretch")
            if c4.button("Delete", key=f"delconv_{conv.id}", width="stretch"):
                svc.workspace.delete_conversation(conv.scope, conv.id)
                active = st.session_state.conversations.get(conv.scope)
                if active and active.id == conv.id:
                    st.session_state.conversations.pop(conv.scope)
                st.rerun()
