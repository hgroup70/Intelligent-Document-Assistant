import pytest

from src.core.document_processor import clean_text, extract_document
from src.core.errors import DocumentProcessingError, FileTooLargeError, UnsupportedFileError
from tests.conftest import make_pdf


def test_pdf_extraction_keeps_pages(sample_pdf):
    doc = extract_document("report.pdf", sample_pdf)
    assert doc.file_type == "pdf"
    assert doc.page_count == 3
    assert "12 percent" in doc.pages[0].text
    assert doc.pages[2].number == 3
    assert doc.word_count > 10
    assert len(doc.sha256) == 64


def test_text_extraction_and_encodings():
    doc = extract_document("notes.txt", "Héllo wörld\r\n\r\n\r\nSecond para".encode("cp1252"))
    assert doc.file_type == "text"
    assert doc.page_count is None
    assert doc.full_text == "Héllo wörld\n\nSecond para"


def test_utf8_bom_text():
    doc = extract_document("a.md", "\ufeff# Title\nBody".encode("utf-8-sig"))
    assert doc.full_text.startswith("# Title")


def test_unsupported_extension():
    with pytest.raises(UnsupportedFileError):
        extract_document("image.png", b"\x89PNG....")


def test_empty_file():
    with pytest.raises(DocumentProcessingError):
        extract_document("empty.txt", b"")


def test_file_too_large():
    with pytest.raises(FileTooLargeError):
        extract_document("big.txt", b"a" * (2 * 1024 * 1024), max_size_mb=1)


def test_page_limit(sample_pdf):
    with pytest.raises(FileTooLargeError):
        extract_document("report.pdf", sample_pdf, max_pages=2)


def test_corrupted_pdf():
    with pytest.raises(DocumentProcessingError):
        extract_document("broken.pdf", b"%PDF-1.4 this is not really a pdf")


def test_pdf_without_text_is_rejected():
    blank = make_pdf(["", ""])
    with pytest.raises(DocumentProcessingError, match="scanned"):
        extract_document("scan.pdf", blank)


def test_binary_disguised_as_text():
    with pytest.raises(DocumentProcessingError):
        extract_document("x.txt", b"abc\x00\x01\x02def")


def test_clean_text_rejoins_hyphenation_and_spaces():
    assert clean_text("infor-\nmation   here\n\n\n\nnext") == "information here\n\nnext"
