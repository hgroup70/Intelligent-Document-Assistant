# Remote Work Pilot - Final Report

## Background
In January the operations team launched a six-month pilot allowing 120 employees across three departments to work remotely up to four days per week. The goal was to measure the effect on productivity, employee satisfaction and office costs.

## Method
Participants were compared with a control group of 115 employees who stayed on the standard office schedule. Productivity was measured using completed tickets per week, project milestones hit on time, and manager ratings. Satisfaction was measured with a monthly 10-question survey.

## Results
- Productivity among remote participants rose by 9% on average, driven mainly by the engineering department (+14%). Customer support saw no significant change.
- Employee satisfaction scores increased from 6.8 to 8.1 out of 10, while the control group stayed flat at 6.9.
- Voluntary attrition in the pilot group was 2%, compared with 7% in the control group.
- Office costs fell by an estimated 18% as one floor was sub-leased from April onwards.

## Challenges
New hires in the pilot group reported feeling less connected to their teams, and onboarding took about two weeks longer. Some managers struggled to run hybrid meetings fairly, and video-conferencing licences added unplanned costs of roughly 12,000 dollars.

## Conclusions and Recommendations
The pilot met or exceeded its targets for productivity, satisfaction and cost. The committee recommends:
1. Extending the hybrid policy to all eligible departments from next quarter.
2. Requiring at least two in-office days per month for employees in their first six months.
3. Training all managers in running hybrid meetings.
4. Re-evaluating the policy after twelve months using the same metrics.
