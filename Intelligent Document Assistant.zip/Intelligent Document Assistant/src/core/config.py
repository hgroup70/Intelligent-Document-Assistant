"""Central configuration, loaded from environment variables / a ``.env`` file."""

from __future__ import annotations

import os
from dataclasses import dataclass, field, replace
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(PROJECT_ROOT / ".env")

PROVIDER_OPENAI = "openai"
PROVIDER_GEMINI = "gemini"
PROVIDER_LABELS = {PROVIDER_OPENAI: "OpenAI", PROVIDER_GEMINI: "Google Gemini"}


def _env_str(name: str, default: str | None = None) -> str | None:
    value = os.getenv(name)
    if value is None or value.strip() == "":
        return default
    return value.strip()


def _env_int(name: str, default: int, minimum: int | None = None) -> int:
    try:
        value = int(_env_str(name, str(default)))  # type: ignore[arg-type]
    except ValueError:
        value = default
    if minimum is not None:
        value = max(minimum, value)
    return value


def _env_float(name: str, default: float) -> float:
    try:
        return float(_env_str(name, str(default)))  # type: ignore[arg-type]
    except ValueError:
        return default


def _env_bool(name: str, default: bool = False) -> bool:
    value = _env_str(name)
    if value is None:
        return default
    return value.lower() in {"1", "true", "yes", "on"}


def _parse_users(raw: str | None) -> dict[str, str]:
    """Parse ``APP_USERS="alice:secret,bob:sha256:<hex>"`` into a dict."""
    users: dict[str, str] = {}
    if not raw:
        return users
    for entry in raw.split(","):
        entry = entry.strip()
        if not entry or ":" not in entry:
            continue
        username, password = entry.split(":", 1)
        if username.strip():
            users[username.strip()] = password.strip()
    return users


@dataclass(frozen=True)
class ProviderConfig:
    """Everything needed to instantiate a chat model + embeddings."""

    provider: str
    api_key: str
    chat_model: str
    embedding_model: str
    temperature: float = 0.2

    @property
    def embedding_signature(self) -> str:
        """Identifies a vector index: indexes built with different embedding
        models are not interchangeable."""
        slug = self.embedding_model.replace("/", "_").replace(":", "_")
        return f"{self.provider}__{slug}"


@dataclass(frozen=True)
class Settings:
    # Providers
    openai_api_key: str | None
    google_api_key: str | None
    default_provider: str
    openai_chat_model: str
    openai_embedding_model: str
    gemini_chat_model: str
    gemini_embedding_model: str
    temperature: float

    # RAG
    chunk_size: int
    chunk_overlap: int
    retrieval_k: int
    max_history_turns: int

    # Limits
    max_file_size_mb: int
    max_pages: int
    max_documents: int

    # Storage & auth
    data_dir: Path
    auth_enabled: bool
    app_users: dict[str, str] = field(default_factory=dict)

    def api_key_for(self, provider: str) -> str | None:
        return self.openai_api_key if provider == PROVIDER_OPENAI else self.google_api_key

    def configured_providers(self) -> list[str]:
        return [p for p in (PROVIDER_OPENAI, PROVIDER_GEMINI) if self.api_key_for(p)]

    def default_models(self, provider: str) -> tuple[str, str]:
        if provider == PROVIDER_OPENAI:
            return self.openai_chat_model, self.openai_embedding_model
        return self.gemini_chat_model, self.gemini_embedding_model

    def provider_config(
        self,
        provider: str,
        *,
        api_key: str | None = None,
        chat_model: str | None = None,
        temperature: float | None = None,
    ) -> ProviderConfig | None:
        """Build a :class:`ProviderConfig`, or ``None`` if no key is available."""
        key = api_key or self.api_key_for(provider)
        if not key:
            return None
        default_chat, embedding = self.default_models(provider)
        return ProviderConfig(
            provider=provider,
            api_key=key,
            chat_model=chat_model or default_chat,
            embedding_model=embedding,
            temperature=self.temperature if temperature is None else temperature,
        )

    def with_overrides(self, **kwargs) -> "Settings":
        return replace(self, **kwargs)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    default_provider = (_env_str("DEFAULT_PROVIDER", PROVIDER_OPENAI) or PROVIDER_OPENAI).lower()
    if default_provider not in PROVIDER_LABELS:
        default_provider = PROVIDER_OPENAI

    data_dir = Path(_env_str("DATA_DIR", str(PROJECT_ROOT / "data")))  # type: ignore[arg-type]
    if not data_dir.is_absolute():
        data_dir = PROJECT_ROOT / data_dir

    chunk_size = _env_int("CHUNK_SIZE", 1000, minimum=200)
    chunk_overlap = min(_env_int("CHUNK_OVERLAP", 150, minimum=0), chunk_size // 2)

    return Settings(
        openai_api_key=_env_str("OPENAI_API_KEY"),
        google_api_key=_env_str("GOOGLE_API_KEY") or _env_str("GEMINI_API_KEY"),
        default_provider=default_provider,
        openai_chat_model=_env_str("OPENAI_CHAT_MODEL", "gpt-4o-mini"),  # type: ignore[arg-type]
        openai_embedding_model=_env_str("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"),  # type: ignore[arg-type]
        gemini_chat_model=_env_str("GEMINI_CHAT_MODEL", "gemini-2.5-flash"),  # type: ignore[arg-type]
        gemini_embedding_model=_env_str("GEMINI_EMBEDDING_MODEL", "models/gemini-embedding-001"),  # type: ignore[arg-type]
        temperature=_env_float("LLM_TEMPERATURE", 0.2),
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        retrieval_k=_env_int("RETRIEVAL_K", 5, minimum=1),
        max_history_turns=_env_int("MAX_HISTORY_TURNS", 6, minimum=0),
        max_file_size_mb=_env_int("MAX_FILE_SIZE_MB", 50, minimum=1),
        max_pages=_env_int("MAX_PAGES", 500, minimum=1),
        max_documents=_env_int("MAX_DOCUMENTS", 25, minimum=1),
        data_dir=data_dir,
        auth_enabled=_env_bool("AUTH_ENABLED", False),
        app_users=_parse_users(_env_str("APP_USERS")),
    )
