"""Exceptions used across the app. `user_message` is what we show in the UI."""

from __future__ import annotations


class AppError(Exception):
    """Base class for all errors the UI knows how to display."""

    def __init__(self, user_message: str, *, detail: str | None = None) -> None:
        super().__init__(detail or user_message)
        self.user_message = user_message
        self.detail = detail


class ConfigurationError(AppError):
    """Missing API key, unknown provider, bad setting, etc."""


class UnsupportedFileError(AppError):
    """The uploaded file type is not supported."""


class FileTooLargeError(AppError):
    """The uploaded file exceeds the configured size/page limits."""


class DocumentProcessingError(AppError):
    """The file could not be parsed or contains no extractable text."""


class LLMServiceError(AppError):
    """The LLM / embeddings provider returned an error."""


class AuthenticationError(AppError):
    """Login failed."""
