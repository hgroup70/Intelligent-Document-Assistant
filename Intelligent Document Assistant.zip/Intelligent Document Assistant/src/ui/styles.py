"""Extra CSS on top of the theme in .streamlit/config.toml."""

import streamlit as st

_CSS = """
<style>
:root { --accent: #4F46E5; --accent-soft: rgba(79,70,229,0.08); --border: rgba(120,120,140,0.22); }

.block-container { padding-top: 2.2rem; padding-bottom: 6rem; max-width: 1200px; }

/* Brand header in the sidebar */
.brand { display:flex; align-items:center; gap:.6rem; margin-bottom:.25rem; }
.brand-logo { font-size:1.7rem; line-height:1; }
.brand-title { font-weight:700; font-size:1.05rem; line-height:1.2; }
.brand-sub { font-size:.78rem; opacity:.65; }

/* Hero (empty state) */
.hero { padding: 2.2rem 2rem; border-radius: 18px; border:1px solid var(--border);
        background: linear-gradient(135deg, rgba(79,70,229,.10), rgba(14,165,233,.06)); margin-bottom:1.5rem; }
.hero h1 { font-size: 2rem; margin: 0 0 .4rem 0; }
.hero p { font-size: 1.05rem; opacity:.85; margin:0; }

.feature-card { border:1px solid var(--border); border-radius:14px; padding:1.1rem 1.2rem; height:100%;
                background: var(--accent-soft); }
.feature-card h4 { margin:.2rem 0 .35rem 0; font-size:1rem; }
.feature-card p { margin:0; font-size:.9rem; opacity:.8; }

/* Document header */
.doc-title { font-size:1.55rem; font-weight:700; margin-bottom:.1rem; word-break:break-word; }
.doc-meta  { font-size:.85rem; opacity:.65; margin-bottom:.8rem; }
.pill { display:inline-block; padding:.1rem .55rem; border-radius:999px; font-size:.75rem;
        background: var(--accent-soft); border:1px solid var(--border); margin-right:.35rem; }

/* Metrics */
div[data-testid="stMetric"] { border:1px solid var(--border); border-radius:12px; padding:.6rem .9rem; }
div[data-testid="stMetricValue"] { font-size:1.3rem; }

/* Summary card */
.summary-meta { font-size:.8rem; opacity:.6; margin-top:.4rem; }

/* Citations */
.citation { border-left:3px solid var(--accent); padding:.45rem .8rem; margin:.4rem 0 .7rem 0;
            background: var(--accent-soft); border-radius: 0 8px 8px 0; font-size:.88rem; }
.citation-head { font-weight:600; font-size:.8rem; margin-bottom:.2rem; opacity:.85; }
.citation-dim { opacity:.6; }

/* Sidebar document list */
section[data-testid="stSidebar"] .stButton button { text-align:left; justify-content:flex-start; }
section[data-testid="stSidebar"] .stButton button p { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

mark { background: rgba(250, 204, 21, .45); padding: 0 .1rem; border-radius: 3px; }
</style>
"""


def inject_css() -> None:
    st.markdown(_CSS, unsafe_allow_html=True)
