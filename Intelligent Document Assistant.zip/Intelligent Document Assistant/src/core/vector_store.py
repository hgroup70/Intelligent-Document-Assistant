"""Chunking and local FAISS vector indexes (one per document per embedding model)."""

from __future__ import annotations

import logging
import shutil
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING

from .document_processor import PageText
from .errors import AppError
from .llm_provider import to_llm_error

if TYPE_CHECKING:  # pragma: no cover
    from langchain_community.vectorstores import FAISS
    from langchain_core.documents import Document
    from langchain_core.embeddings import Embeddings

logger = logging.getLogger(__name__)

ProgressFn = Callable[[float, str], None]
_EMBED_BATCH = 64


def chunk_pages(
    pages: list[PageText],
    *,
    doc_id: str,
    doc_name: str,
    chunk_size: int,
    chunk_overlap: int,
) -> list["Document"]:
    """Split pages into overlapping chunks, keeping page numbers in metadata."""
    from langchain_core.documents import Document
    from langchain_text_splitters import RecursiveCharacterTextSplitter

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", "? ", "! ", "; ", ", ", " ", ""],
        add_start_index=True,
    )
    chunks: list[Document] = []
    for page in pages:
        if not page.text.strip():
            continue
        for piece in splitter.split_text(page.text):
            chunks.append(
                Document(
                    page_content=piece,
                    metadata={
                        "doc_id": doc_id,
                        "doc_name": doc_name,
                        "page": page.number,
                        "chunk_id": len(chunks),
                    },
                )
            )
    return chunks


class VectorStoreManager:
    """Builds, persists, caches and searches per-document FAISS indexes."""

    def __init__(self) -> None:
        self._cache: dict[str, "FAISS"] = {}

    @staticmethod
    def index_path(index_root: Path, signature: str) -> Path:
        return index_root / signature

    def has_index(self, index_root: Path, signature: str) -> bool:
        return (self.index_path(index_root, signature) / "index.faiss").exists()

    def get_or_build(
        self,
        index_root: Path,
        signature: str,
        embeddings: "Embeddings",
        chunk_factory: Callable[[], list["Document"]],
        progress: ProgressFn | None = None,
    ) -> "FAISS":
        from langchain_community.vectorstores import FAISS

        path = self.index_path(index_root, signature)
        key = str(path)
        if key in self._cache:
            return self._cache[key]

        if (path / "index.faiss").exists():
            try:
                # Safe: we only ever load indexes this app wrote itself.
                store = FAISS.load_local(str(path), embeddings, allow_dangerous_deserialization=True)
                self._cache[key] = store
                return store
            except Exception as exc:  # corrupted index, rebuild it
                logger.warning("Could not load index at %s (%s); rebuilding", path, exc)
                shutil.rmtree(path, ignore_errors=True)

        chunks = chunk_factory()
        if not chunks:
            raise AppError("This document has no text to index.")

        store = None
        total = len(chunks)
        try:
            for start in range(0, total, _EMBED_BATCH):
                batch = chunks[start : start + _EMBED_BATCH]
                if store is None:
                    store = FAISS.from_documents(batch, embeddings)
                else:
                    store.add_documents(batch)
                if progress:
                    done = min(start + _EMBED_BATCH, total)
                    progress(done / total, f"Embedded {done}/{total} chunks")
        except AppError:
            raise
        except Exception as exc:
            raise to_llm_error(exc, signature.split("__")[0]) from exc

        path.mkdir(parents=True, exist_ok=True)
        store.save_local(str(path))
        self._cache[key] = store
        return store

    def evict(self, index_root: Path) -> None:
        prefix = str(index_root)
        for key in [k for k in self._cache if k.startswith(prefix)]:
            del self._cache[key]

    @staticmethod
    def search(stores: list["FAISS"], query: str, k: int) -> list[tuple["Document", float]]:
        """Search one or more indexes and merge by distance (lower is better).

        All indexes passed here share the same embedding model, so L2
        distances are directly comparable.
        """
        results: list[tuple["Document", float]] = []
        for store in stores:
            results.extend(store.similarity_search_with_score(query, k=k))
        results.sort(key=lambda pair: float(pair[1]))
        # De-duplicate identical text (e.g. repeated headers/footers)
        seen: set[str] = set()
        unique: list[tuple["Document", float]] = []
        for doc, score in results:
            fingerprint = doc.page_content.strip()[:200]
            if fingerprint in seen:
                continue
            seen.add(fingerprint)
            unique.append((doc, float(score)))
            if len(unique) >= k:
                break
        return unique
