"""Optional login screen (enabled with AUTH_ENABLED=true)."""

from __future__ import annotations

import time

import streamlit as st

from src.core.auth import authenticate
from src.core.errors import AuthenticationError
from src.ui import state

_MAX_ATTEMPTS = 5
_LOCKOUT_SECONDS = 60


def require_login() -> bool:
    """Render the login form if needed. Returns True when the user is signed in."""
    if st.session_state.workspace_id:
        return True

    s = state.settings()
    _, center, _ = st.columns([1, 1.4, 1])
    with center:
        st.markdown("## Document Assistant")
        st.caption("Sign in to access your private document library.")
        if not s.app_users:
            st.error("Authentication is enabled but no users are configured. Set `APP_USERS` in `.env`.")
            return False

        locked_until = st.session_state.get("login_locked_until", 0)
        if time.time() < locked_until:
            st.warning(f"Too many failed attempts. Try again in {int(locked_until - time.time())} s.")
            return False

        with st.form("login", border=True):
            username = st.text_input("Username", autocomplete="username")
            password = st.text_input("Password", type="password", autocomplete="current-password")
            submitted = st.form_submit_button("Sign in", type="primary", width="stretch")
        if submitted:
            try:
                st.session_state.workspace_id = authenticate(username, password, s.app_users)
                st.session_state.username = username.strip()
                st.session_state.login_attempts = 0
                st.rerun()
            except AuthenticationError as exc:
                attempts = st.session_state.get("login_attempts", 0) + 1
                st.session_state.login_attempts = attempts
                if attempts >= _MAX_ATTEMPTS:
                    st.session_state.login_locked_until = time.time() + _LOCKOUT_SECONDS
                    st.session_state.login_attempts = 0
                st.error(exc.user_message)
    return False
