"""Question answering over the indexed documents.

For each question: rewrite follow-ups into a standalone query (only when
there's history), retrieve the top-k chunks, then ask the model to answer
from those chunks and cite them as [n].
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterator
from dataclasses import asdict, dataclass, field
from typing import TYPE_CHECKING

from .llm_provider import content_to_text, to_llm_error
from .prompts import CONDENSE_SYSTEM_PROMPT, QA_SYSTEM_PROMPT
from .storage import ChatMessage

if TYPE_CHECKING:  # pragma: no cover
    from langchain_core.documents import Document
    from langchain_core.language_models import BaseChatModel

RetrieverFn = Callable[[str, int], list[tuple["Document", float]]]

_CITATION_RE = re.compile(r"\[(\d{1,2})\]")
_EXCERPT_CHARS = 700


@dataclass
class Citation:
    index: int
    doc_id: str
    doc_name: str
    page: int | None
    chunk_id: int | None
    excerpt: str
    score: float
    cited: bool = False

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def location(self) -> str:
        return f"page {self.page}" if self.page else f"chunk {self.chunk_id}"


@dataclass
class RetrievalResult:
    question: str
    standalone_question: str
    citations: list[Citation] = field(default_factory=list)

    @property
    def context(self) -> str:
        blocks = []
        for c in self.citations:
            where = f", page {c.page}" if c.page else ""
            blocks.append(f"[{c.index}] (source: {c.doc_name}{where})\n{c.excerpt}")
        return "\n\n".join(blocks)


def mark_cited(answer: str, citations: list[Citation]) -> list[Citation]:
    """Flag the citations the answer actually references, cited ones first."""
    used = {int(n) for n in _CITATION_RE.findall(answer)}
    for c in citations:
        c.cited = c.index in used
    return sorted(citations, key=lambda c: (not c.cited, c.index))


class QAEngine:
    def __init__(
        self,
        llm: "BaseChatModel",
        retriever: RetrieverFn,
        *,
        provider: str,
        k: int = 5,
        max_history_turns: int = 6,
    ) -> None:
        self.llm = llm
        self.retriever = retriever
        self.provider = provider
        self.k = k
        self.max_history_turns = max_history_turns
    def _history_messages(self, history: list[ChatMessage]):
        from langchain_core.messages import AIMessage, HumanMessage

        turns = history[-self.max_history_turns * 2 :] if self.max_history_turns else []
        return [
            HumanMessage(content=m.content) if m.role == "user" else AIMessage(content=m.content)
            for m in turns
        ]

    def condense(self, question: str, history: list[ChatMessage]) -> str:
        if not history or not self.max_history_turns:
            return question
        from langchain_core.messages import HumanMessage, SystemMessage

        transcript = "\n".join(
            f"{'User' if m.role == 'user' else 'Assistant'}: {m.content[:1500]}"
            for m in history[-self.max_history_turns * 2 :]
        )
        try:
            response = self.llm.invoke([
                SystemMessage(content=CONDENSE_SYSTEM_PROMPT),
                HumanMessage(content=f"Conversation:\n{transcript}\n\nFollow-up question: {question}"),
            ])
        except Exception as exc:
            raise to_llm_error(exc, self.provider) from exc
        rewritten = content_to_text(response.content).strip().strip('"')
        return rewritten or question

    def retrieve(self, question: str, history: list[ChatMessage]) -> RetrievalResult:
        standalone = self.condense(question, history)
        try:
            hits = self.retriever(standalone, self.k)
        except Exception as exc:
            raise to_llm_error(exc, self.provider) from exc
        citations = [
            Citation(
                index=i,
                doc_id=doc.metadata.get("doc_id", ""),
                doc_name=doc.metadata.get("doc_name", "document"),
                page=doc.metadata.get("page"),
                chunk_id=doc.metadata.get("chunk_id"),
                excerpt=doc.page_content[:_EXCERPT_CHARS * 2],
                score=score,
            )
            for i, (doc, score) in enumerate(hits, start=1)
        ]
        return RetrievalResult(question=question, standalone_question=standalone, citations=citations)

    def _answer_messages(self, retrieval: RetrievalResult, history: list[ChatMessage]):
        from langchain_core.messages import HumanMessage, SystemMessage

        context = retrieval.context or "(no relevant excerpts were found)"
        return [
            SystemMessage(content=QA_SYSTEM_PROMPT.format(context=context)),
            *self._history_messages(history),
            HumanMessage(content=retrieval.question),
        ]

    def stream_answer(self, retrieval: RetrievalResult, history: list[ChatMessage]) -> Iterator[str]:
        """Yield answer tokens. Errors are raised as LLMServiceError."""
        messages = self._answer_messages(retrieval, history)
        try:
            for chunk in self.llm.stream(messages):
                text = content_to_text(chunk.content)
                if text:
                    yield text
        except Exception as exc:
            raise to_llm_error(exc, self.provider) from exc

    def answer(self, question: str, history: list[ChatMessage]) -> tuple[str, list[Citation]]:
        """Non-streaming convenience wrapper (used by tests / scripts)."""
        retrieval = self.retrieve(question, history)
        text = "".join(self.stream_answer(retrieval, history))
        return text, mark_cited(text, retrieval.citations)
