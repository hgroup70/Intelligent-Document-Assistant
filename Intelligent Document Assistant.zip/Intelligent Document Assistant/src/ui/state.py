"""Session state helpers."""

from __future__ import annotations

import re

import streamlit as st

from src.core.auth import new_anonymous_workspace_id
from src.core.config import ProviderConfig, Settings, get_settings
from src.core.service import DocumentService
from src.core.storage import Conversation, DocumentRecord, Workspace, cleanup_stale_workspaces
from src.core.vector_store import VectorStoreManager

_ANON_RE = re.compile(r"^anon_[0-9a-f]{16}$")

VIEW_SUMMARY = "Summary"
VIEW_CHAT = "Ask questions"
VIEW_TEXT = "Document text"
VIEW_HISTORY = "Saved sessions"
VIEWS = [VIEW_SUMMARY, VIEW_CHAT, VIEW_TEXT, VIEW_HISTORY]


@st.cache_resource(show_spinner=False)
def _vector_manager() -> VectorStoreManager:
    """Shared across sessions; cache keys are workspace-specific paths."""
    return VectorStoreManager()


@st.cache_resource(show_spinner=False)
def _startup_cleanup(data_dir: str) -> int:
    from pathlib import Path

    return cleanup_stale_workspaces(Path(data_dir))


def settings() -> Settings:
    return get_settings()


def init_state() -> None:
    s = settings()
    _startup_cleanup(str(s.data_dir))
    defaults = {
        "workspace_id": None,
        "username": None,
        "active_doc_id": None,
        "provider": (s.configured_providers() or [s.default_provider])[0]
        if s.default_provider not in s.configured_providers() else s.default_provider,
        "api_keys": {},
        "chat_models": {},
        "temperature": s.temperature,
        "retrieval_k": s.retrieval_k,
        "summary_style": "medium",
        "search_all_docs": False,
        "conversations": {},  # scope -> Conversation
        "uploader_key": 0,
        "flash": [],
        "pending_question": None,
        "view": VIEW_SUMMARY,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def ensure_anonymous_workspace() -> None:
    """Give each browser session its own workspace. The id is mirrored in the
    URL (``?ws=``) so a page refresh keeps the user's documents."""
    if st.session_state.workspace_id:
        return
    from_url = st.query_params.get("ws")
    if from_url and _ANON_RE.match(from_url):
        st.session_state.workspace_id = from_url
    else:
        st.session_state.workspace_id = new_anonymous_workspace_id()
        st.query_params["ws"] = st.session_state.workspace_id


def service() -> DocumentService:
    s = settings()
    ws = Workspace(s.data_dir, st.session_state.workspace_id)
    return DocumentService(s, ws, _vector_manager())


def provider_config() -> ProviderConfig | None:
    p = st.session_state.provider
    return settings().provider_config(
        p,
        api_key=st.session_state.api_keys.get(p),
        chat_model=st.session_state.chat_models.get(p),
        temperature=st.session_state.temperature,
    )


def flash(kind: str, message: str) -> None:
    """Queue a message to show after the next rerun."""
    st.session_state.flash.append((kind, message))


def show_flash() -> None:
    for kind, message in st.session_state.flash:
        getattr(st, kind, st.info)(message)
    st.session_state.flash = []


def active_document(svc: DocumentService) -> DocumentRecord | None:
    docs = svc.workspace.list_documents()
    if not docs:
        st.session_state.active_doc_id = None
        return None
    doc = next((d for d in docs if d.id == st.session_state.active_doc_id), None)
    if doc is None:
        doc = docs[0]
        st.session_state.active_doc_id = doc.id
    return doc


def chat_scope(doc: DocumentRecord) -> str:
    return "all" if st.session_state.search_all_docs else f"doc:{doc.id}"


def active_conversation(svc: DocumentService, scope: str) -> Conversation:
    convs: dict[str, Conversation] = st.session_state.conversations
    if scope not in convs:
        convs[scope] = svc.workspace.latest_conversation(scope)
    return convs[scope]


def set_conversation(conv: Conversation) -> None:
    st.session_state.conversations[conv.scope] = conv


def navigate(view: str) -> None:
    """Request a view change; applied before the nav widget is created."""
    st.session_state.nav_request = view


def apply_navigation() -> None:
    request = st.session_state.pop("nav_request", None)
    if request in VIEWS:
        st.session_state.view = request


def select_document(doc_id: str) -> None:
    st.session_state.active_doc_id = doc_id
    st.session_state.pending_question = None
