import pytest

from src.core.auth import authenticate, hash_password, verify_password
from src.core.document_processor import extract_document
from src.core.errors import AuthenticationError
from src.core.export import conversation_to_markdown, markdown_to_pdf, safe_filename, summary_to_markdown
from src.core.qa_engine import Citation, mark_cited
from src.core.storage import ChatMessage, Workspace
from src.core.summarizer import build_sections
from src.core.document_processor import PageText


@pytest.fixture
def workspace(tmp_path):
    return Workspace(tmp_path, "test_user")


def test_document_lifecycle(workspace, sample_pdf):
    extracted = extract_document("report.pdf", sample_pdf)
    record = workspace.add_document(extracted)
    assert workspace.get_document(record.id).name == "report.pdf"
    assert workspace.find_by_hash(extracted.sha256).id == record.id
    assert len(workspace.load_pages(record.id)) == 3

    workspace.save_summary(record.id, "short", {"content": "## Overview\nHi", "style": "short"})
    assert workspace.get_summaries(record.id)["short"]["content"].startswith("## Overview")

    workspace.delete_document(record.id)
    assert workspace.list_documents() == []
    assert not workspace.doc_dir(record.id).exists()


def test_workspaces_are_isolated(tmp_path, sample_pdf):
    a, b = Workspace(tmp_path, "alice"), Workspace(tmp_path, "bob")
    a.add_document(extract_document("r.pdf", sample_pdf))
    assert len(a.list_documents()) == 1
    assert b.list_documents() == []


def test_workspace_id_is_sanitized(tmp_path):
    ws = Workspace(tmp_path, "../../etc/passwd")
    assert tmp_path in ws.root.parents


def test_conversation_persistence(workspace):
    conv = workspace.new_conversation("doc:abc")
    workspace.save_conversation(conv)  # empty not saved
    assert workspace.list_conversations("doc:abc") == []

    conv.messages.append(ChatMessage(role="user", content="What is it?"))
    conv.messages.append(ChatMessage(role="assistant", content="A report [1].",
                                     citations=[{"index": 1, "doc_name": "r.pdf", "page": 2,
                                                 "chunk_id": 0, "excerpt": "text", "cited": True}]))
    workspace.save_conversation(conv)
    loaded = workspace.latest_conversation("doc:abc")
    assert loaded.id == conv.id and len(loaded.messages) == 2
    assert loaded.messages[1].citations[0]["page"] == 2

    md = conversation_to_markdown(loaded, ["r.pdf"])
    assert "What is it?" in md and "p. 2" in md

    workspace.delete_conversation("doc:abc", conv.id)
    assert workspace.list_conversations() == []


def test_summary_markdown_and_pdf(workspace, sample_pdf):
    record = workspace.add_document(extract_document("report.pdf", sample_pdf))
    summary = {"style": "medium", "content": "## Overview\nA **bold** claim - 'quoted'.\n\n"
               "## Key Insights\n- First *point*\n- Second `code`\n\n1. one\n2. two",
               "created_at": "2026-01-01T00:00:00+00:00", "provider": "openai", "model": "x"}
    md = summary_to_markdown(record, summary)
    assert md.startswith("# Summary - report.pdf")
    pdf = markdown_to_pdf(md, "t")
    assert pdf.startswith(b"%PDF") and len(pdf) > 1000


def test_safe_filename():
    assert safe_filename("My Report (final).pdf", ".md") == "My_Report_final.md"


def test_password_verification():
    assert verify_password("secret", "secret")
    assert verify_password("secret", hash_password("secret"))
    assert not verify_password("wrong", hash_password("secret"))


def test_authenticate():
    users = {"alice": "pw", "bob": hash_password("pw2")}
    assert authenticate("alice", "pw", users) == "user_alice"
    assert authenticate(" bob ", "pw2", users) == "user_bob"
    with pytest.raises(AuthenticationError):
        authenticate("alice", "nope", users)
    with pytest.raises(AuthenticationError):
        authenticate("mallory", "pw", users)


def test_mark_cited_orders_cited_first():
    cites = [Citation(i, "d", "doc", i, i, "x", 0.1 * i) for i in range(1, 4)]
    ordered = mark_cited("Answer uses [3] and [1].", cites)
    assert [c.index for c in ordered] == [1, 3, 2]
    assert [c.cited for c in ordered] == [True, True, False]


def test_build_sections_respects_size():
    pages = [PageText(i, "word " * 1000) for i in range(1, 21)]  # ~5k chars each
    sections = build_sections(pages, section_chars=12_000)
    assert 8 <= len(sections) <= 11
    assert sections[0].startswith("[Page 1]")
    assert all(len(s) <= 12_000 + 100 for s in sections)


def test_build_sections_splits_long_text():
    pages = [PageText(None, "\n\n".join(["para " * 200] * 50))]
    sections = build_sections(pages, section_chars=12_000)
    assert len(sections) > 1
